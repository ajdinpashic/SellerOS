import { useState } from 'react';
import { I18nProvider } from '@/locales';
import { AppLayout } from '@/layouts/AppLayout';
import { useRouter } from '@/hooks/useRouter';
import { DashboardPage } from '@/pages/DashboardPage';
import { OrdersPage } from '@/pages/OrdersPage';
import { OrderDetailPage } from '@/pages/OrderDetailPage';
import { CreateOrderPage } from '@/pages/CreateOrderPage';
import { ProductsPage } from '@/pages/ProductsPage';
import { ProductDetailPage } from '@/pages/ProductDetailPage';
import { InventoryPage } from '@/pages/InventoryPage';
import { CustomersPage } from '@/pages/CustomersPage';
import { CustomerDetailPage } from '@/pages/CustomerDetailPage';
import { ShippingPage } from '@/pages/ShippingPage';
import { InvoicesPage } from '@/pages/InvoicesPage';
import { ReportsPage } from '@/pages/ReportsPage';
import { IntegrationsPage } from '@/pages/IntegrationsPage';
import { SettingsPage } from '@/pages/SettingsPage';
import { mockOrders } from '@/data/orders';
import type { Order } from '@/types';

export default function App() {
  const { route, navigate } = useRouter();
  const [orders, setOrders] = useState<Order[]>(mockOrders);

  const handleCreateOrder = (order: Order) => {
    setOrders((prev) => [order, ...prev]);
  };

  let page: React.ReactNode;
  switch (route.name) {
    case 'dashboard': page = <DashboardPage navigate={navigate} />; break;
    case 'orders': page = <OrdersPage navigate={navigate} />; break;
    case 'order-detail': page = <OrderDetailPage orderId={route.id} navigate={navigate} />; break;
    case 'create-order': page = <CreateOrderPage navigate={navigate} onCreate={handleCreateOrder} />; break;
    case 'products': page = <ProductsPage navigate={navigate} />; break;
    case 'product-detail': page = <ProductDetailPage productId={route.id} navigate={navigate} />; break;
    case 'inventory': page = <InventoryPage />; break;
    case 'customers': page = <CustomersPage navigate={navigate} />; break;
    case 'customer-detail': page = <CustomerDetailPage customerId={route.id} navigate={navigate} />; break;
    case 'shipping': page = <ShippingPage />; break;
    case 'invoices': page = <InvoicesPage />; break;
    case 'reports': page = <ReportsPage />; break;
    case 'integrations': page = <IntegrationsPage />; break;
    case 'settings': page = <SettingsPage />; break;
    default: page = <DashboardPage navigate={navigate} />;
  }

  return (
    <I18nProvider>
      <AppLayout route={route} navigate={navigate}>
        {page}
      </AppLayout>
    </I18nProvider>
  );
}
