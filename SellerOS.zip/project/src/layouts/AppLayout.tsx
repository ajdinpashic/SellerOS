import { useState, type ReactNode } from 'react';
import { Sidebar } from '@/components/Sidebar';
import { Header } from '@/components/Header';
import { useI18n } from '@/locales';
import type { Route } from '@/hooks/useRouter';
import { classNames } from '@/utils/format';

interface AppLayoutProps {
  route: Route;
  navigate: (route: Route) => void;
  children: ReactNode;
}

const routeTitles: Record<Route['name'], keyof ReturnType<typeof useI18n>['t']> = {
  dashboard: 'dashboard',
  orders: 'orders',
  'order-detail': 'orders',
  'create-order': 'createOrder',
  products: 'products',
  'product-detail': 'products',
  inventory: 'inventory',
  customers: 'customers',
  'customer-detail': 'customers',
  shipping: 'shipping',
  invoices: 'invoices',
  reports: 'reports',
  integrations: 'integrations',
  settings: 'settings',
};

export function AppLayout({ route, navigate, children }: AppLayoutProps) {
  const { t } = useI18n();
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  const titleKey = routeTitles[route.name];
  const title = t[titleKey] as string;

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50">
      <Sidebar
        current={route.name}
        navigate={navigate}
        mobileOpen={mobileSidebarOpen}
        onCloseMobile={() => setMobileSidebarOpen(false)}
      />
      <div className="flex flex-1 flex-col overflow-hidden">
        <Header
          title={title}
          onMenuClick={() => setMobileSidebarOpen(true)}
          navigate={navigate}
        />
        <main className={classNames(
          'flex-1 overflow-y-auto',
        )}>
          <div className="mx-auto max-w-[1400px] px-4 py-6 lg:px-8">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
