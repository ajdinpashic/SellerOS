import {
  ArrowLeft, Package, TrendingUp, Boxes, Tag, Layers,
  CheckCircle2, XCircle, DollarSign,
} from 'lucide-react';
import { PageHeader } from '@/components/PageHeader';
import { SectionCard } from '@/components/MetricCard';
import { ChannelBadge } from '@/components/Badges';
import { useI18n } from '@/locales';
import { formatKM, classNames } from '@/utils/format';
import { mockProducts } from '@/data/products';
import { topProductsReport } from '@/data/misc';
import type { SalesChannel } from '@/types';
import type { Route } from '@/hooks/useRouter';

interface ProductDetailPageProps {
  productId: string;
  navigate: (route: Route) => void;
}

const allChannels: SalesChannel[] = ['olx', 'instagram', 'facebook', 'webshop'];

export function ProductDetailPage({ productId, navigate }: ProductDetailPageProps) {
  const { t, lang } = useI18n();
  const product = mockProducts.find((p) => p.id === productId);

  if (!product) {
    return (
      <div>
        <PageHeader title={t.productDetail} breadcrumb={[{ label: t.products, onClick: () => navigate({ name: 'products' }) }, { label: productId }]} />
        <div className="card p-12 text-center text-slate-500">{t.noProducts}</div>
      </div>
    );
  }

  const profit = product.price - product.cost;
  const margin = product.price > 0 ? Math.round((profit / product.price) * 100) : 0;
  const reportData = topProductsReport.find((r) => r.name === product.name);
  const stockStatus = product.stock === 0
    ? { label: t.outOfStock, classes: 'bg-red-50 text-red-700 border-red-200' }
    : product.stock <= product.minimumStock
    ? { label: t.lowStock, classes: 'bg-amber-50 text-amber-700 border-amber-200' }
    : { label: t.active, classes: 'bg-emerald-50 text-emerald-700 border-emerald-200' };

  const stats = [
    { label: t.price, value: formatKM(product.price, lang), icon: DollarSign, bg: 'bg-blue-50' },
    { label: t.cost, value: formatKM(product.cost, lang), icon: Tag, bg: 'bg-slate-100' },
    { label: t.profit, value: formatKM(profit, lang), icon: TrendingUp, bg: 'bg-emerald-50' },
    { label: t.stock, value: `${product.stock}`, icon: Boxes, bg: 'bg-amber-50' },
  ];

  return (
    <div>
      <PageHeader
        title={product.name}
        breadcrumb={[
          { label: t.products, onClick: () => navigate({ name: 'products' }) },
          { label: product.name },
        ]}
        actions={
          <button onClick={() => navigate({ name: 'products' })} className="btn-secondary">
            <ArrowLeft className="h-4 w-4" /> {t.back}
          </button>
        }
      />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        {/* Left: image + description + channels */}
        <div className="lg:col-span-2 space-y-4">
          {/* Product image placeholder */}
          <div className="card shadow-card overflow-hidden">
            <div className="flex h-56 items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100">
              <Package className="h-20 w-20 text-slate-300" />
            </div>
            <div className="p-5">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h2 className="text-xl font-bold text-slate-900">{product.name}</h2>
                  <p className="text-sm text-slate-400 mt-0.5">{t.sku}: {product.sku}</p>
                </div>
                <span className={classNames('inline-flex items-center rounded-full border px-3 py-1 text-sm font-medium', stockStatus.classes)}>
                  {stockStatus.label}
                </span>
              </div>
            </div>
          </div>

          {/* Description */}
          <SectionCard title={t.description}>
            <div className="px-5 py-4">
              <p className="text-sm text-slate-600 leading-relaxed">{product.description}</p>
              <div className="mt-4 flex items-center gap-2">
                <Layers className="h-4 w-4 text-slate-400" />
                <span className="text-sm text-slate-500">{t.category}: </span>
                <span className="text-sm font-medium text-slate-700">{product.category}</span>
              </div>
            </div>
          </SectionCard>

          {/* Channel connections */}
          <SectionCard title={t.salesChannels}>
            <div className="grid grid-cols-2 gap-3 p-5 sm:grid-cols-4">
              {allChannels.map((ch) => {
                const connected = product.channels.includes(ch);
                return (
                  <div key={ch} className={classNames(
                    'flex flex-col items-center gap-2 rounded-lg border p-4 transition-colors',
                    connected ? 'border-blue-200 bg-blue-50/50' : 'border-slate-200 bg-slate-50',
                  )}>
                    <ChannelBadge channel={ch} />
                    {connected ? (
                      <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                    ) : (
                      <XCircle className="h-5 w-5 text-slate-300" />
                    )}
                    <span className={classNames('text-xs', connected ? 'text-emerald-600 font-medium' : 'text-slate-400')}>
                      {connected ? t.int_connected : t.int_disconnected}
                    </span>
                  </div>
                );
              })}
            </div>
          </SectionCard>
        </div>

        {/* Right: stats */}
        <div className="space-y-4">
          <div className="card shadow-card p-5">
            <h3 className="text-base font-semibold text-slate-900 mb-4">{t.productDetail}</h3>
            <div className="grid grid-cols-2 gap-3">
              {stats.map((s) => (
                <div key={s.label} className="rounded-lg border border-slate-100 p-3">
                  <div className={classNames('flex h-9 w-9 items-center justify-center rounded-lg mb-2', s.bg)}>
                    <s.icon className="h-4 w-4 text-slate-700" />
                  </div>
                  <p className="text-xs text-slate-500">{s.label}</p>
                  <p className="text-lg font-bold text-slate-900 tnum">{s.value}</p>
                </div>
              ))}
            </div>
            <div className="mt-4 border-t border-slate-100 pt-4 space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-slate-500">{t.margin}</span>
                <span className="font-semibold text-slate-900 tnum">{margin}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">{t.minStock}</span>
                <span className="font-semibold text-slate-900 tnum">{product.minimumStock}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">{t.reserved}</span>
                <span className="font-semibold text-slate-900 tnum">{product.reserved}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">{t.available}</span>
                <span className="font-semibold text-slate-900 tnum">{Math.max(product.stock - product.reserved, 0)}</span>
              </div>
              {reportData && (
                <div className="flex justify-between">
                  <span className="text-slate-500">{t.unitsSold}</span>
                  <span className="font-semibold text-slate-900 tnum">{reportData.sold}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
