import { useState } from 'react';
import { ArrowLeft, Plus, Trash2, Check, User as UserIcon, Package as PackageIcon } from 'lucide-react';
import { PageHeader } from '@/components/PageHeader';
import { Modal } from '@/components/Modal';
import { useI18n } from '@/locales';
import { formatKM, classNames } from '@/utils/format';
import { mockProducts } from '@/data/products';
import { mockCustomers } from '@/data/customers';
import { mockOrders } from '@/data/orders';
import type { Order, OrderItem, PaymentMethod, SalesChannel } from '@/types';
import type { Route } from '@/hooks/useRouter';

interface CreateOrderPageProps {
  navigate: (route: Route) => void;
  onCreate: (order: Order) => void;
}

const channels: { value: SalesChannel | 'manual'; labelKey: string }[] = [
  { value: 'olx', labelKey: 'ch_olx' },
  { value: 'instagram', labelKey: 'ch_instagram' },
  { value: 'facebook', labelKey: 'ch_facebook' },
  { value: 'webshop', labelKey: 'ch_webshop' },
  { value: 'manual', labelKey: 'manualEntry' },
];

const payments: { value: PaymentMethod; labelKey: string }[] = [
  { value: 'cod', labelKey: 'pay_cod' },
  { value: 'paid', labelKey: 'pay_paid' },
  { value: 'card', labelKey: 'pay_card' },
  { value: 'other', labelKey: 'pay_other' },
];

export function CreateOrderPage({ navigate, onCreate }: CreateOrderPageProps) {
  const { t, lang } = useI18n();
  const [customerId, setCustomerId] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [channel, setChannel] = useState<SalesChannel | 'manual'>('webshop');
  const [items, setItems] = useState<OrderItem[]>([{ productId: '', name: '', quantity: 1, price: 0 }]);
  const [shipping, setShipping] = useState(8);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cod');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [note, setNote] = useState('');
  const [successOpen, setSuccessOpen] = useState(false);
  const [createdId, setCreatedId] = useState('');

  const subtotal = items.reduce((s, i) => s + i.quantity * i.price, 0);
  const total = subtotal + shipping;

  const handleCustomerSelect = (id: string) => {
    setCustomerId(id);
    const c = mockCustomers.find((x) => x.id === id);
    if (c) {
      setCustomerName(c.name);
      setAddress(`${c.address}, ${c.city}`);
      setPhone(c.phone);
      setEmail(c.email);
    }
  };

  const handleProductSelect = (idx: number, pid: string) => {
    const p = mockProducts.find((x) => x.id === pid);
    setItems((prev) => prev.map((it, i) =>
      i === idx ? { ...it, productId: pid, name: p?.name || '', price: p?.price || 0 } : it,
    ));
  };

  const updateItem = (idx: number, patch: Partial<OrderItem>) => {
    setItems((prev) => prev.map((it, i) => (i === idx ? { ...it, ...patch } : it)));
  };

  const addItem = () => setItems((prev) => [...prev, { productId: '', name: '', quantity: 1, price: 0 }]);
  const removeItem = (idx: number) => setItems((prev) => prev.filter((_, i) => i !== idx));

  const canSave = customerName.trim() && items.some((i) => i.productId) && address.trim();

  const handleSave = () => {
    const validItems = items.filter((i) => i.productId);
    const nextNum = 1043 + mockOrders.length;
    const id = `#${nextNum}`;
    const newOrder: Order = {
      id,
      customerId: customerId || 'manual',
      customerName,
      channel: (channel === 'manual' ? 'webshop' : channel) as SalesChannel,
      items: validItems,
      shipping,
      paymentMethod,
      status: 'pending',
      date: new Date().toISOString(),
      address,
      phone,
      email,
      note: note || undefined,
      timeline: [
        { status: 'received', label: 'tl_received', timestamp: new Date().toISOString(), done: true },
        { status: 'confirmed', label: 'tl_confirmed', timestamp: '', done: false },
        { status: 'ready', label: 'tl_packing', timestamp: '', done: false },
        { status: 'shipped', label: 'tl_shipped', timestamp: '', done: false },
        { status: 'delivered', label: 'tl_delivered', timestamp: '', done: false },
      ],
    };
    onCreate(newOrder);
    setCreatedId(id);
    setSuccessOpen(true);
  };

  return (
    <div>
      <PageHeader
        title={t.createOrder}
        breadcrumb={[{ label: t.orders, onClick: () => navigate({ name: 'orders' }) }, { label: t.createOrder }]}
        actions={
          <button onClick={() => navigate({ name: 'orders' })} className="btn-secondary">
            <ArrowLeft className="h-4 w-4" /> {t.backToOrders}
          </button>
        }
      />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-4">
          {/* Customer + channel */}
          <div className="card shadow-card p-5">
            <h3 className="text-base font-semibold text-slate-900 mb-4">{t.customerInfo}</h3>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label className="label">{t.selectCustomer}</label>
                <select className="input cursor-pointer" value={customerId} onChange={(e) => handleCustomerSelect(e.target.value)}>
                  <option value="">—</option>
                  {mockCustomers.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div>
                <label className="label">{t.customerName}</label>
                <input className="input" value={customerName} onChange={(e) => setCustomerName(e.target.value)} placeholder={t.customerPlaceholder} />
              </div>
              <div>
                <label className="label">{t.channelLabel}</label>
                <select className="input cursor-pointer" value={channel} onChange={(e) => setChannel(e.target.value as SalesChannel | 'manual')}>
                  {channels.map((c) => <option key={c.value} value={c.value}>{t[c.labelKey as keyof typeof t] as string}</option>)}
                </select>
              </div>
              <div>
                <label className="label">{t.paymentLabel}</label>
                <select className="input cursor-pointer" value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}>
                  {payments.map((p) => <option key={p.value} value={p.value}>{t[p.labelKey as keyof typeof t] as string}</option>)}
                </select>
              </div>
              <div className="sm:col-span-2">
                <label className="label">{t.address}</label>
                <input className="input" value={address} onChange={(e) => setAddress(e.target.value)} />
              </div>
              <div>
                <label className="label">{t.phone}</label>
                <input className="input" value={phone} onChange={(e) => setPhone(e.target.value)} />
              </div>
              <div>
                <label className="label">{t.email}</label>
                <input className="input" value={email} onChange={(e) => setEmail(e.target.value)} />
              </div>
            </div>
          </div>

          {/* Items */}
          <div className="card shadow-card p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-semibold text-slate-900">{t.orderItems}</h3>
              <button onClick={addItem} className="btn-secondary text-sm">
                <Plus className="h-4 w-4" /> {t.addItem}
              </button>
            </div>
            <div className="space-y-3">
              {items.map((item, idx) => (
                <div key={idx} className="flex flex-col gap-2 rounded-lg border border-slate-200 p-3 sm:flex-row sm:items-end">
                  <div className="flex-1">
                    <label className="label">{t.selectProduct}</label>
                    <select className="input cursor-pointer" value={item.productId} onChange={(e) => handleProductSelect(idx, e.target.value)}>
                      <option value="">—</option>
                      {mockProducts.map((p) => <option key={p.id} value={p.id}>{p.name} — {formatKM(p.price, lang)}</option>)}
                    </select>
                  </div>
                  <div className="w-20">
                    <label className="label">{t.quantityLabel}</label>
                    <input type="number" min={1} className="input tnum" value={item.quantity} onChange={(e) => updateItem(idx, { quantity: parseInt(e.target.value) || 1 })} />
                  </div>
                  <div className="w-28">
                    <label className="label">{t.priceLabel}</label>
                    <input type="number" className="input tnum" value={item.price} onChange={(e) => updateItem(idx, { price: parseFloat(e.target.value) || 0 })} />
                  </div>
                  <div className="w-24 text-right">
                    <label className="label">{t.amount}</label>
                    <p className="py-2 text-sm font-semibold text-slate-900 tnum">{formatKM(item.quantity * item.price, lang)}</p>
                  </div>
                  <button onClick={() => removeItem(idx)} className="btn-ghost text-red-500 hover:bg-red-50">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
            <div className="mt-4 border-t border-slate-100 pt-4 space-y-2">
              <div className="flex items-center gap-3">
                <label className="label mb-0 flex-1">{t.shippingCost}</label>
                <input type="number" className="input w-32 tnum" value={shipping} onChange={(e) => setShipping(parseFloat(e.target.value) || 0)} />
              </div>
              <div className="flex justify-between text-sm text-slate-600">
                <span>{t.subtotal}</span>
                <span className="tnum">{formatKM(subtotal, lang)}</span>
              </div>
              <div className="flex justify-between text-base font-bold text-slate-900">
                <span>{t.total}</span>
                <span className="tnum">{formatKM(total, lang)}</span>
              </div>
            </div>
          </div>

          {/* Note */}
          <div className="card shadow-card p-5">
            <label className="label">{t.noteLabel}</label>
            <textarea className="input min-h-[80px] resize-y" value={note} onChange={(e) => setNote(e.target.value)} />
          </div>
        </div>

        {/* Summary sidebar */}
        <div className="space-y-4">
          <div className="card shadow-card p-5 sticky top-20">
            <h3 className="text-base font-semibold text-slate-900 mb-4">{t.createOrder}</h3>
            <div className="space-y-3 text-sm">
              <div className="flex items-center gap-2 text-slate-600">
                <UserIcon className="h-4 w-4 text-slate-400" />
                <span className={classNames(!customerName && 'text-slate-300')}>{customerName || '—'}</span>
              </div>
              <div className="flex items-center gap-2 text-slate-600">
                <PackageIcon className="h-4 w-4 text-slate-400" />
                <span>{items.filter((i) => i.productId).length} {t.products}</span>
              </div>
              <div className="border-t border-slate-100 pt-3 flex justify-between font-bold text-slate-900">
                <span>{t.total}</span>
                <span className="tnum">{formatKM(total, lang)}</span>
              </div>
            </div>
            <button onClick={handleSave} disabled={!canSave} className="btn-primary w-full mt-4">
              <Check className="h-4 w-4" /> {t.save}
            </button>
            <button onClick={() => navigate({ name: 'orders' })} className="btn-secondary w-full mt-2">
              {t.cancelBtn}
            </button>
          </div>
        </div>
      </div>

      <Modal
        open={successOpen}
        onClose={() => navigate({ name: 'order-detail', id: createdId })}
        title={t.orderCreated}
        footer={
          <>
            <button onClick={() => navigate({ name: 'orders' })} className="btn-secondary">{t.backToOrders}</button>
            <button onClick={() => navigate({ name: 'order-detail', id: createdId })} className="btn-primary">{t.viewDetails}</button>
          </>
        }
      >
        <div className="flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-emerald-50">
            <Check className="h-6 w-6 text-emerald-600" />
          </div>
          <p className="text-sm text-slate-600">{t.orderNumber} {createdId} — {customerName}</p>
        </div>
      </Modal>
    </div>
  );
}
