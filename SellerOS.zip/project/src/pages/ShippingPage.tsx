import { useState, useMemo } from 'react';
import { Truck, Package, MapPin, Clock, CheckCircle2, AlertTriangle, Search } from 'lucide-react';
import { PageHeader } from '@/components/PageHeader';
import { ShipmentStatusBadge } from '@/components/Badges';
import { EmptyState } from '@/components/EmptyState';
import { Modal } from '@/components/Modal';
import { useI18n } from '@/locales';
import { formatDate, formatDateTime, classNames } from '@/utils/format';
import { mockShipments } from '@/data/misc';
import type { ShipmentStatus, Shipment } from '@/types';

const tabs: { key: ShipmentStatus | 'all'; labelKey: string }[] = [
  { key: 'all', labelKey: 'all' },
  { key: 'pending', labelKey: 'awaitingShipment' },
  { key: 'shipped', labelKey: 'shippedTab' },
  { key: 'delivered', labelKey: 'deliveredTab' },
  { key: 'problem', labelKey: 'problem' },
];

export function ShippingPage() {
  const { t, lang } = useI18n();
  const [activeTab, setActiveTab] = useState<ShipmentStatus | 'all'>('all');
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<Shipment | null>(null);

  const filtered = useMemo(() => {
    return mockShipments.filter((s) => {
      const matchesTab = activeTab === 'all' || s.status === activeTab;
      const matchesSearch = !search ||
        s.orderId.toLowerCase().includes(search.toLowerCase()) ||
        s.customerName.toLowerCase().includes(search.toLowerCase()) ||
        s.trackingNumber.toLowerCase().includes(search.toLowerCase());
      return matchesTab && matchesSearch;
    });
  }, [activeTab, search]);

  const counts = useMemo(() => ({
    all: mockShipments.length,
    pending: mockShipments.filter((s) => s.status === 'pending').length,
    shipped: mockShipments.filter((s) => s.status === 'shipped').length,
    delivered: mockShipments.filter((s) => s.status === 'delivered').length,
    problem: mockShipments.filter((s) => s.status === 'problem').length,
  }), []);

  return (
    <div>
      <PageHeader title={t.shipping} subtitle={`${filtered.length} ${t.resultsCount}`} />

      {/* Tabs */}
      <div className="flex items-center gap-1 overflow-x-auto border-b border-slate-200 mb-4">
        {tabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={classNames(
              'flex items-center gap-2 whitespace-nowrap border-b-2 px-4 py-2.5 text-sm font-medium transition-colors',
              activeTab === tab.key ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-700',
            )}
          >
            {t[tab.labelKey as keyof typeof t] as string}
            <span className={classNames(
              'rounded-full px-1.5 py-0.5 text-xs tnum',
              activeTab === tab.key ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-500',
            )}>
              {counts[tab.key]}
            </span>
          </button>
        ))}
      </div>

      {/* Search */}
      <div className="mb-4">
        <div className="relative max-w-sm">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t.search}
            className="input pl-9"
          />
        </div>
      </div>

      <div className="card shadow-card overflow-hidden">
        {filtered.length === 0 ? (
          <EmptyState icon={Truck} title={t.noShipments} description={t.noResultsDesc} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b border-slate-200 bg-slate-50/50">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">{t.invoiceOrder}</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">{t.customer}</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">{t.carrier}</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">{t.tracking}</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">{t.status}</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">{t.estimatedDelivery}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((s) => (
                  <tr key={s.id} onClick={() => setSelected(s)} className="cursor-pointer hover:bg-slate-50 transition-colors">
                    <td className="px-4 py-3.5 font-medium text-slate-900 whitespace-nowrap">{s.orderId}</td>
                    <td className="px-4 py-3.5 text-slate-700 whitespace-nowrap">{s.customerName}</td>
                    <td className="px-4 py-3.5 text-slate-600 whitespace-nowrap">{s.carrier}</td>
                    <td className="px-4 py-3.5 font-mono text-xs text-slate-500 whitespace-nowrap">{s.trackingNumber}</td>
                    <td className="px-4 py-3.5 whitespace-nowrap"><ShipmentStatusBadge status={s.status} /></td>
                    <td className="px-4 py-3.5 text-slate-500 whitespace-nowrap">{s.estimatedDelivery ? formatDate(s.estimatedDelivery, lang) : '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Tracking detail modal */}
      <Modal
        open={!!selected}
        onClose={() => setSelected(null)}
        title={selected ? `${t.tracking} — ${selected.trackingNumber}` : ''}
        description={selected ? `${selected.orderId} · ${selected.customerName}` : ''}
        size="lg"
        footer={<button onClick={() => setSelected(null)} className="btn-secondary">{t.close}</button>}
      >
        {selected && (
          <div className="space-y-4">
            <div className="flex items-center gap-3 rounded-lg bg-slate-50 px-4 py-3">
              <Truck className="h-5 w-5 text-slate-500" />
              <div className="flex-1">
                <p className="text-sm font-medium text-slate-900">{selected.carrier}</p>
                <p className="text-xs text-slate-400 font-mono">{selected.trackingNumber}</p>
              </div>
              <ShipmentStatusBadge status={selected.status} />
            </div>

            <div>
              <h4 className="text-sm font-semibold text-slate-900 mb-3">{t.trackingTimeline}</h4>
              <div className="relative">
                {selected.timeline.map((event, i) => {
                  const isLast = i === selected.timeline.length - 1;
                  const isProblem = selected.status === 'problem' && !event.done && event.label.includes('adres');
                  return (
                    <div key={i} className="flex gap-3">
                      <div className="flex flex-col items-center">
                        {event.done ? (
                          <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                        ) : isProblem ? (
                          <AlertTriangle className="h-5 w-5 text-amber-500" />
                        ) : (
                          <div className="h-5 w-5 rounded-full border-2 border-slate-200" />
                        )}
                        {!isLast && <div className={classNames('w-0.5 flex-1 min-h-[1.5rem]', event.done ? 'bg-emerald-200' : 'bg-slate-200')} />}
                      </div>
                      <div className="pb-4 min-h-[2rem]">
                        <p className={classNames('text-sm font-medium', event.done ? 'text-slate-900' : 'text-slate-400')}>
                          {event.label}
                        </p>
                        {event.timestamp && (
                          <p className="text-xs text-slate-400 mt-0.5">{formatDateTime(event.timestamp, lang)}</p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
