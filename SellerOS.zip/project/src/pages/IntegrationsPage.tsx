import { useState } from 'react';
import {
  ShoppingBag, Instagram, Facebook, ShoppingCart, Store,
  Truck, Package, Mail, Zap, Plug, Check, BellRing, AlertTriangle,
} from 'lucide-react';
import * as LucideIcons from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { PageHeader } from '@/components/PageHeader';
import { SectionCard } from '@/components/MetricCard';
import { IntegrationStatusBadge } from '@/components/Badges';
import { Modal } from '@/components/Modal';
import { useI18n } from '@/locales';
import { classNames } from '@/utils/format';
import { mockIntegrations } from '@/data/misc';
import type { Integration } from '@/types';

export function IntegrationsPage() {
  const { t } = useI18n();
  const [selected, setSelected] = useState<Integration | null>(null);
  const [notifyToast, setNotifyToast] = useState(false);

  const iconMap: Record<string, LucideIcon> = {
    ShoppingBag, Instagram, Facebook, ShoppingCart, Store,
    Truck, Package, Mail, Zap,
  };

  const salesIntegrations = mockIntegrations.filter((i) => i.category === 'sales');
  const shippingIntegrations = mockIntegrations.filter((i) => i.category === 'shipping');

  const renderCard = (int: Integration) => {
    const Icon = iconMap[int.icon] || Plug;
    const connected = int.status === 'connected';
    return (
      <div key={int.id} className="card shadow-card p-5 flex flex-col transition-shadow hover:shadow-card-hover">
        <div className="flex items-start justify-between mb-3">
          <div className={classNames('flex h-12 w-12 items-center justify-center rounded-xl text-white', int.color)}>
            <Icon className="h-6 w-6" />
          </div>
          <IntegrationStatusBadge status={int.status} />
        </div>
        <h3 className="font-semibold text-slate-900">{int.name}</h3>
        <p className="mt-1 text-sm text-slate-500 flex-1">{int.description}</p>
        <div className="mt-4 pt-4 border-t border-slate-100">
          {connected ? (
            <button
              onClick={() => setSelected(int)}
              className="btn-secondary w-full"
            >
              {t.configure}
            </button>
          ) : (
            <button
              onClick={() => setSelected(int)}
              className="btn-primary w-full"
            >
              <Plug className="h-4 w-4" /> {t.connect}
            </button>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <PageHeader title={t.integrations} subtitle={t.tagline} />

      {/* Hero banner */}
      <div className="rounded-xl border border-slate-200 bg-gradient-to-br from-slate-900 to-slate-800 p-6 text-white shadow-card">
        <div className="flex items-center gap-3 mb-2">
          <Plug className="h-6 w-6 text-blue-400" />
          <h2 className="text-lg font-bold">{t.integrations}</h2>
        </div>
        <p className="text-sm text-slate-300 max-w-2xl">
          {t.welcomeMessage} Povežite OLX, Instagram, Facebook, webshop i kurirske službe na jednom mjestu.
        </p>
      </div>

      {/* Sales channels */}
      <SectionCard title={t.salesChannelsInt}>
        <div className="grid grid-cols-1 gap-4 p-5 sm:grid-cols-2 lg:grid-cols-3">
          {salesIntegrations.map(renderCard)}
        </div>
      </SectionCard>

      {/* Shipping providers */}
      <SectionCard title={t.shippingProviders}>
        <div className="grid grid-cols-1 gap-4 p-5 sm:grid-cols-2 lg:grid-cols-4">
          {shippingIntegrations.map(renderCard)}
        </div>
      </SectionCard>

      {/* Integration modal */}
      <Modal
        open={!!selected}
        onClose={() => setSelected(null)}
        title={selected ? `${t.integrationModalTitle} ${selected.name}` : ''}
        footer={
          <>
            <button onClick={() => setSelected(null)} className="btn-secondary">{t.close}</button>
            <button
              onClick={() => { setSelected(null); setNotifyToast(true); setTimeout(() => setNotifyToast(false), 2500); }}
              className="btn-primary"
            >
              <BellRing className="h-4 w-4" /> {t.notifyMe}
            </button>
          </>
        }
      >
        {selected && (
          <div className="space-y-4">
            <div className={classNames('flex h-14 w-14 items-center justify-center rounded-xl text-white', selected.color)}>
              {(() => {
                const Icon = iconMap[selected.icon] || Plug;
                return <Icon className="h-7 w-7" />;
              })()}
            </div>
            <div className="rounded-lg bg-amber-50 border border-amber-200 p-4 flex items-start gap-3">
              <AlertTriangle className="h-5 w-5 text-amber-500 mt-0.5 shrink-0" />
              <div>
                <p className="font-medium text-amber-900">{t.integrationModalMsg}</p>
                <p className="mt-1 text-sm text-amber-700">{t.integrationModalDesc}</p>
              </div>
            </div>
            <div className="flex items-center gap-2 text-sm text-slate-500">
              <Check className="h-4 w-4 text-emerald-500" />
              <span>{t.integrationModalDesc.split('.')[0]}.</span>
            </div>
          </div>
        )}
      </Modal>

      {notifyToast && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 rounded-lg bg-slate-900 px-4 py-3 text-sm text-white shadow-popover animate-slide-up z-50">
          {t.notifyMe} — {t.saved}
        </div>
      )}
    </div>
  );
}
