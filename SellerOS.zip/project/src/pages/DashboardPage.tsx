import { useState, useMemo } from 'react';
import {
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip,
  LineChart, Line, XAxis, YAxis, CartesianGrid, Area, AreaChart,
} from 'recharts';
import {
  DollarSign, ShoppingBag, UserPlus, Receipt, ArrowRight,
  Package, TrendingUp, AlertTriangle,
} from 'lucide-react';
import { MetricCard, SectionCard } from '@/components/MetricCard';
import { OrderStatusBadge, ChannelBadge } from '@/components/Badges';
import { Table, THead, TBody, TR, TH, TD } from '@/components/Table';
import { useI18n } from '@/locales';
import { formatKM, formatDate, orderTotal, classNames } from '@/utils/format';
import { mockOrders } from '@/data/orders';
import { mockProducts } from '@/data/products';
import { salesByChannel, salesOverTime } from '@/data/misc';
import type { Route } from '@/hooks/useRouter';

interface DashboardProps {
  navigate: (route: Route) => void;
}

const rangeKeys = ['today', '7days', '30days', 'thisMonth', 'thisYear'] as const;
type RangeKey = typeof rangeKeys[number];

export function DashboardPage({ navigate }: DashboardProps) {
  const { t, lang } = useI18n();
  const [range, setRange] = useState<RangeKey>('7days');

  const latestOrders = useMemo(() =>
    [...mockOrders].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 6),
  []);

  const lowStockProducts = useMemo(() =>
    mockProducts.filter((p) => p.stock > 0 && p.stock <= p.minimumStock).slice(0, 5),
  []);

  const chartData = salesOverTime[range];

  const rangeLabels: Record<RangeKey, string> = {
    today: t.today,
    '7days': t['7days'],
    '30days': t['30days'],
    thisMonth: t.thisMonth,
    thisYear: t.thisYear,
  };

  return (
    <div className="space-y-6">
      {/* Metrics */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <MetricCard label={t.totalSales} value={formatKM(7850, lang)} delta={12} deltaLabel={t.vsLastMonth} icon={DollarSign} iconBg="bg-blue-50" />
        <MetricCard label={t.ordersLabel} value="156" delta={8} deltaLabel={t.vsLastMonth} icon={ShoppingBag} iconBg="bg-purple-50" />
        <MetricCard label={t.newCustomers} value="42" delta={15} deltaLabel={t.vsLastMonth} icon={UserPlus} iconBg="bg-emerald-50" />
        <MetricCard label={t.avgOrder} value={formatKM(50.30, lang)} delta={-3} deltaLabel={t.vsLastMonth} icon={Receipt} iconBg="bg-amber-50" />
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        {/* Sales over time */}
        <div className="lg:col-span-2">
          <SectionCard
            title={t.salesOverTime}
            action={
              <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-0.5">
                {rangeKeys.map((k) => (
                  <button
                    key={k}
                    onClick={() => setRange(k)}
                    className={classNames(
                      'rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors',
                      range === k ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700',
                    )}
                  >
                    {rangeLabels[k]}
                  </button>
                ))}
              </div>
            }
          >
            <div className="h-72 px-2 py-4">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="salesGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#2563eb" stopOpacity={0.15} />
                      <stop offset="100%" stopColor="#2563eb" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                  <XAxis dataKey="label" tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v}`} />
                  <Tooltip
                    contentStyle={{ borderRadius: '8px', border: '1px solid #e2e8f0', fontSize: '13px', boxShadow: '0 4px 12px rgba(0,0,0,0.08)' }}
                    formatter={(v: number) => [formatKM(v, lang), t.totalSales]}
                  />
                  <Area type="monotone" dataKey="value" stroke="#2563eb" strokeWidth={2.5} fill="url(#salesGradient)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </SectionCard>
        </div>

        {/* Sales by channel donut */}
        <SectionCard title={t.salesByChannel}>
          <div className="flex flex-col items-center px-4 py-4">
            <div className="relative h-48 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={salesByChannel}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={80}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {salesByChannel.map((entry, i) => (
                      <Cell key={i} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ borderRadius: '8px', border: '1px solid #e2e8f0', fontSize: '13px' }}
                    formatter={(v: number) => [`${v}%`, '']}
                  />
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                <span className="text-2xl font-bold text-slate-900 tnum">100%</span>
                <span className="text-xs text-slate-400">4 {t.ch_olx === 'OLX' ? 'kanala' : 'channels'}</span>
              </div>
            </div>
            <div className="mt-4 w-full space-y-2">
              {salesByChannel.map((ch) => (
                <div key={ch.channel} className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: ch.color }} />
                    <span className="text-slate-700">{ch.channel}</span>
                  </div>
                  <span className="font-semibold text-slate-900 tnum">{ch.value}%</span>
                </div>
              ))}
            </div>
          </div>
        </SectionCard>
      </div>

      {/* Latest orders + low stock */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <SectionCard
            title={t.latestOrders}
            action={
              <button onClick={() => navigate({ name: 'orders' })} className="flex items-center gap-1 text-sm font-medium text-blue-600 hover:text-blue-700">
                {t.viewAll}
                <ArrowRight className="h-3.5 w-3.5" />
              </button>
            }
          >
            <Table>
              <THead>
                <TR>
                  <TH>{t.orderId}</TH>
                  <TH>{t.customer}</TH>
                  <TH>{t.channel}</TH>
                  <TH>{t.amount}</TH>
                  <TH>{t.status}</TH>
                  <TH>{t.date}</TH>
                </TR>
              </THead>
              <TBody>
                {latestOrders.map((order) => (
                  <TR key={order.id} onClick={() => navigate({ name: 'order-detail', id: order.id })}>
                    <TD className="font-medium text-slate-900">{order.id}</TD>
                    <TD>{order.customerName}</TD>
                    <TD><ChannelBadge channel={order.channel} /></TD>
                    <TD className="font-medium tnum">{formatKM(orderTotal(order.items, order.shipping), lang)}</TD>
                    <TD><OrderStatusBadge status={order.status} /></TD>
                    <TD className="text-slate-500">{formatDate(order.date, lang)}</TD>
                  </TR>
                ))}
              </TBody>
            </Table>
          </SectionCard>
        </div>

        <SectionCard
          title={t.lowStock}
          action={
            <button onClick={() => navigate({ name: 'inventory' })} className="flex items-center gap-1 text-sm font-medium text-blue-600 hover:text-blue-700">
              {t.viewAll}
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          }
        >
          <div className="divide-y divide-slate-100">
            {lowStockProducts.length === 0 ? (
              <div className="px-5 py-10 text-center text-sm text-slate-400">{t.noLowStock}</div>
            ) : (
              lowStockProducts.map((p) => (
                <div key={p.id} className="flex items-center justify-between px-5 py-3.5">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-slate-900">{p.name}</p>
                    <p className="text-xs text-slate-400">{p.sku}</p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <AlertTriangle className="h-4 w-4 text-amber-500" />
                    <span className="text-sm font-semibold text-amber-600 tnum">{p.stock}</span>
                    <span className="text-xs text-slate-400">/ {p.minimumStock}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </SectionCard>
      </div>
    </div>
  );
}
