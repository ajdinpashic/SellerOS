import { useState, useMemo } from 'react';
import { Plus, Package, AlertTriangle, CircleSlash } from 'lucide-react';
import { PageHeader } from '@/components/PageHeader';
import { FilterBar, type FilterOption } from '@/components/FilterBar';
import { ChannelBadge } from '@/components/Badges';
import { Table, THead, TBody, TR, TH, TD } from '@/components/Table';
import { EmptyState } from '@/components/EmptyState';
import { useI18n } from '@/locales';
import { formatKM, classNames } from '@/utils/format';
import { mockProducts } from '@/data/products';
import type { Product, SalesChannel } from '@/types';
import type { Route } from '@/hooks/useRouter';

interface ProductsPageProps {
  navigate: (route: Route) => void;
}

type SortField = 'name' | 'price' | 'stock' | 'profit';
type SortDir = 'asc' | 'desc';

export function ProductsPage({ navigate }: ProductsPageProps) {
  const { t, lang } = useI18n();
  const [search, setSearch] = useState('');
  const [channelFilter, setChannelFilter] = useState('');
  const [sortField, setSortField] = useState<SortField>('name');
  const [sortDir, setSortDir] = useState<SortDir>('asc');

  const channelOptions: FilterOption[] = (['olx', 'instagram', 'facebook', 'webshop'] as SalesChannel[]).map((c) => ({
    value: c, label: t[`ch_${c}` as keyof typeof t] as string,
  }));

  const filtered = useMemo(() => {
    let result: Product[] = mockProducts.filter((p) => {
      const matchesSearch = !search ||
        p.name.toLowerCase().includes(search.toLowerCase()) ||
        p.sku.toLowerCase().includes(search.toLowerCase());
      const matchesChannel = !channelFilter || p.channels.includes(channelFilter as SalesChannel);
      return matchesSearch && matchesChannel;
    });
    result = result.sort((a, b) => {
      let cmp = 0;
      switch (sortField) {
        case 'name': cmp = a.name.localeCompare(b.name); break;
        case 'price': cmp = a.price - b.price; break;
        case 'stock': cmp = a.stock - b.stock; break;
        case 'profit': cmp = (a.price - a.cost) - (b.price - b.cost); break;
      }
      return sortDir === 'asc' ? cmp : -cmp;
    });
    return result;
  }, [search, channelFilter, sortField, sortDir]);

  const handleSort = (field: SortField) => {
    if (sortField === field) setSortDir((d) => d === 'asc' ? 'desc' : 'asc');
    else { setSortField(field); setSortDir('asc'); }
  };

  const clearFilters = () => { setSearch(''); setChannelFilter(''); };

  const stockStatus = (p: Product) => {
    if (p.stock === 0) return { label: t.outOfStock, classes: 'text-red-600 bg-red-50' };
    if (p.stock <= p.minimumStock) return { label: t.lowStock, classes: 'text-amber-600 bg-amber-50' };
    return { label: t.active, classes: 'text-emerald-600 bg-emerald-50' };
  };

  return (
    <div>
      <PageHeader
        title={t.products}
        subtitle={`${filtered.length} ${t.resultsCount}`}
        actions={<button className="btn-primary"><Plus className="h-4 w-4" /> {t.newProduct}</button>}
      />

      <div className="card shadow-card p-4">
        <FilterBar
          searchValue={search}
          onSearchChange={setSearch}
          searchPlaceholder={t.search}
          onClear={clearFilters}
          filters={[
            { key: 'channel', value: channelFilter, onChange: setChannelFilter, options: channelOptions, placeholder: t.allChannels },
          ]}
        />
      </div>

      <div className="card shadow-card mt-4 overflow-hidden">
        {filtered.length === 0 ? (
          <EmptyState icon={Package} title={t.noResults} description={t.noResultsDesc}
            action={<button onClick={clearFilters} className="btn-secondary">{t.clearFilters}</button>} />
        ) : (
          <Table>
            <THead>
              <TR>
                <TH>{t.image}</TH>
                <TH sortable active={sortField === 'name'} direction={sortDir} onClick={() => handleSort('name')}>{t.product}</TH>
                <TH>{t.sku}</TH>
                <TH sortable active={sortField === 'price'} direction={sortDir} onClick={() => handleSort('price')}>{t.price}</TH>
                <TH>{t.cost}</TH>
                <TH sortable active={sortField === 'profit'} direction={sortDir} onClick={() => handleSort('profit')}>{t.profit}</TH>
                <TH sortable active={sortField === 'stock'} direction={sortDir} onClick={() => handleSort('stock')}>{t.stock}</TH>
                <TH>{t.status}</TH>
              </TR>
            </THead>
            <TBody>
              {filtered.map((p) => {
                const st = stockStatus(p);
                const profit = p.price - p.cost;
                const margin = p.price > 0 ? Math.round((profit / p.price) * 100) : 0;
                return (
                  <TR key={p.id} onClick={() => navigate({ name: 'product-detail', id: p.id })}>
                    <TD>
                      <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-slate-100">
                        <Package className="h-5 w-5 text-slate-400" />
                      </div>
                    </TD>
                    <TD>
                      <p className="font-medium text-slate-900">{p.name}</p>
                      <p className="text-xs text-slate-400">{p.category}</p>
                    </TD>
                    <TD className="text-slate-500 font-mono text-xs">{p.sku}</TD>
                    <TD className="font-medium tnum">{formatKM(p.price, lang)}</TD>
                    <TD className="text-slate-500 tnum">{formatKM(p.cost, lang)}</TD>
                    <TD>
                      <p className="font-medium tnum text-emerald-600">{formatKM(profit, lang)}</p>
                      <p className="text-xs text-slate-400 tnum">{margin}% {t.margin}</p>
                    </TD>
                    <TD className="tnum">
                      <span className={classNames('font-medium', p.stock === 0 ? 'text-red-600' : p.stock <= p.minimumStock ? 'text-amber-600' : 'text-slate-700')}>
                        {p.stock}
                      </span>
                    </TD>
                    <TD>
                      <span className={classNames('inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium', st.classes)}>
                        {p.stock === 0 ? <CircleSlash className="h-3 w-3" /> : p.stock <= p.minimumStock ? <AlertTriangle className="h-3 w-3" /> : null}
                        {st.label}
                      </span>
                    </TD>
                  </TR>
                );
              })}
            </TBody>
          </Table>
        )}
      </div>
    </div>
  );
}
