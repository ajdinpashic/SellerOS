import { ArrowLeft, User, Mail, Phone, MapPin, ShoppingBag, DollarSign, StickyNote, Calendar } from 'lucide-react';
import { PageHeader } from '@/components/PageHeader';
import { SectionCard, StatCard } from '@/components/MetricCard';
import { ChannelBadge, OrderStatusBadge } from '@/components/Badges';
import { Table, THead, TBody, TR, TH, TD } from '@/components/Table';
import { useI18n } from '@/locales';
import { formatKM, formatDate, orderTotal } from '@/utils/format';
import { mockCustomers } from '@/data/customers';
import { mockOrders } from '@/data/orders';
import type { Route } from '@/hooks/useRouter';

interface CustomerDetailPageProps {
  customerId: string;
  navigate: (route: Route) => void;
}

export function CustomerDetailPage({ customerId, navigate }: CustomerDetailPageProps) {
  const { t, lang } = useI18n();
  const customer = mockCustomers.find((c) => c.id === customerId);

  if (!customer) {
    return (
      <div>
        <PageHeader title={t.customerDetail} breadcrumb={[{ label: t.customers, onClick: () => navigate({ name: 'customers' }) }, { label: customerId }]} />
        <div className="card p-12 text-center text-slate-500">{t.noCustomers}</div>
      </div>
    );
  }

  const orders = mockOrders.filter((o) => o.customerId === customer.id);
  const avgOrder = customer.orderCount > 0 ? customer.totalSpent / customer.orderCount : 0;

  return (
    <div>
      <PageHeader
        title={customer.name}
        breadcrumb={[
          { label: t.customers, onClick: () => navigate({ name: 'customers' }) },
          { label: customer.name },
        ]}
        actions={
          <button onClick={() => navigate({ name: 'customers' })} className="btn-secondary">
            <ArrowLeft className="h-4 w-4" /> {t.back}
          </button>
        }
      />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        {/* Left: order history */}
        <div className="lg:col-span-2 space-y-4">
          <div className="grid grid-cols-3 gap-3">
            <StatCard label={t.orderCount} value={`${customer.orderCount}`} icon={ShoppingBag} iconBg="bg-blue-50" />
            <StatCard label={t.totalSpent} value={formatKM(customer.totalSpent, lang)} icon={DollarSign} iconBg="bg-emerald-50" />
            <StatCard label={t.averageOrder} value={formatKM(avgOrder, lang)} icon={Calendar} iconBg="bg-amber-50" />
          </div>

          <SectionCard title={t.orderHistory}>
            {orders.length === 0 ? (
              <div className="px-5 py-10 text-center text-sm text-slate-400">{t.noOrders}</div>
            ) : (
              <Table>
                <THead>
                  <TR>
                    <TH>{t.orderId}</TH>
                    <TH>{t.channel}</TH>
                    <TH>{t.amount}</TH>
                    <TH>{t.status}</TH>
                    <TH>{t.date}</TH>
                  </TR>
                </THead>
                <TBody>
                  {orders.map((o) => (
                    <TR key={o.id} onClick={() => navigate({ name: 'order-detail', id: o.id })}>
                      <TD className="font-medium text-slate-900">{o.id}</TD>
                      <TD><ChannelBadge channel={o.channel} /></TD>
                      <TD className="font-medium tnum">{formatKM(orderTotal(o.items, o.shipping), lang)}</TD>
                      <TD><OrderStatusBadge status={o.status} /></TD>
                      <TD className="text-slate-500">{formatDate(o.date, lang)}</TD>
                    </TR>
                  ))}
                </TBody>
              </Table>
            )}
          </SectionCard>
        </div>

        {/* Right: profile + contact */}
        <div className="space-y-4">
          <div className="card shadow-card p-5">
            <h3 className="text-base font-semibold text-slate-900 mb-4">{t.profile}</h3>
            <div className="flex flex-col items-center text-center pb-4 border-b border-slate-100">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-blue-500 to-blue-700 text-white text-xl font-bold">
                {customer.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}
              </div>
              <p className="mt-3 font-semibold text-slate-900">{customer.name}</p>
              <p className="text-sm text-slate-400">{customer.city}</p>
              <div className="mt-2">
                <ChannelBadge channel={customer.primaryChannel} />
              </div>
            </div>
            <div className="space-y-3 pt-4">
              <div className="flex items-center gap-2.5 text-sm text-slate-600">
                <Mail className="h-4 w-4 text-slate-400" /> {customer.email}
              </div>
              <div className="flex items-center gap-2.5 text-sm text-slate-600">
                <Phone className="h-4 w-4 text-slate-400" /> {customer.phone}
              </div>
              <div className="flex items-start gap-2.5 text-sm text-slate-600">
                <MapPin className="h-4 w-4 text-slate-400 mt-0.5" /> {customer.address}, {customer.city}
              </div>
            </div>
          </div>

          {customer.notes && (
            <div className="card shadow-card p-5">
              <div className="flex items-start gap-3">
                <StickyNote className="h-5 w-5 text-amber-500 mt-0.5" />
                <div>
                  <p className="text-sm font-semibold text-slate-900">{t.notes}</p>
                  <p className="mt-1 text-sm text-slate-600">{customer.notes}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
