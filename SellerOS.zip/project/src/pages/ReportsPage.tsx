import { useState } from 'react';
import {
  BarChart, Bar, PieChart, Pie, Cell, ResponsiveContainer, Tooltip,
  XAxis, YAxis, CartesianGrid, AreaChart, Area, Legend,
} from 'recharts';
import { TrendingUp, DollarSign, ShoppingBag, Receipt } from 'lucide-react';
import { PageHeader } from '@/components/PageHeader';
import { MetricCard, SectionCard } from '@/components/MetricCard';
import { useI18n } from '@/locales';
import { formatKM, classNames } from '@/utils/format';
import { salesByChannel, salesOverTime, topProductsReport, orderStatusReport } from '@/data/misc';

const rangeKeys = ['7days', '30days', 'thisMonth', 'thisYear'] as const;
type RangeKey = typeof rangeKeys[number];

export function ReportsPage() {
  const { t, lang } = useI18n();
  const [range, setRange] = useState<RangeKey>('30days');

  const chartData = salesOverTime[range];
  const totalRevenue = chartData.reduce((s, d) => s + d.value, 0);

  const rangeLabels: Record<RangeKey, string> = {
    '7days': t['7days'],
    '30days': t['30days'],
    thisMonth: t.thisMonth,
    thisYear: t.thisYear,
  };

  return (
    <div className="space-y-4">
      <PageHeader title={t.reports} />

      {/* Metrics */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <MetricCard label={t.revenue} value={formatKM(18450, lang)} delta={14} deltaLabel={t.vsLastMonth} icon={DollarSign} iconBg="bg-blue-50" />
        <MetricCard label={t.ordersLabel} value="156" delta={8} deltaLabel={t.vsLastMonth} icon={ShoppingBag} iconBg="bg-purple-50" />
        <MetricCard label={t.profitLabel} value={formatKM(7820, lang)} delta={11} deltaLabel={t.vsLastMonth} icon={TrendingUp} iconBg="bg-emerald-50" />
        <MetricCard label={t.avgOrderValue} value={formatKM(118.27, lang)} delta={5} deltaLabel={t.vsLastMonth} icon={Receipt} iconBg="bg-amber-50" />
      </div>

      {/* Sales trend with range selector */}
      <SectionCard
        title={t.salesTrend}
        action={
          <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-0.5">
            {rangeKeys.map((k) => (
              <button
                key={k}
                onClick={() => setRange(k)}
                className={classNames(
                  'rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors',
                  range === k ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700',
                )}
              >
                {rangeLabels[k]}
              </button>
            ))}
          </div>
        }
      >
        <div className="h-72 px-2 py-4">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="reportGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#2563eb" stopOpacity={0.15} />
                  <stop offset="100%" stopColor="#2563eb" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis dataKey="label" tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{ borderRadius: '8px', border: '1px solid #e2e8f0', fontSize: '13px' }}
                formatter={(v: number) => [formatKM(v, lang), t.revenue]}
              />
              <Area type="monotone" dataKey="value" stroke="#2563eb" strokeWidth={2.5} fill="url(#reportGradient)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </SectionCard>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {/* Sales by channel */}
        <SectionCard title={t.salesByChannel}>
          <div className="h-64 px-2 py-4">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={salesByChannel} cx="50%" cy="50%" outerRadius={85} dataKey="value" label={({ channel, value }) => `${channel} ${value}%`} labelLine={false}>
                  {salesByChannel.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                </Pie>
                <Tooltip contentStyle={{ borderRadius: '8px', border: '1px solid #e2e8f0', fontSize: '13px' }} formatter={(v: number) => [`${v}%`, '']} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </SectionCard>

        {/* Order statuses */}
        <SectionCard title={t.orderStatuses}>
          <div className="h-64 px-2 py-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={orderStatusReport} layout="vertical" margin={{ left: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <YAxis type="category" dataKey="status" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} width={80} />
                <Tooltip contentStyle={{ borderRadius: '8px', border: '1px solid #e2e8f0', fontSize: '13px' }} />
                <Bar dataKey="count" radius={[0, 4, 4, 0]}>
                  {orderStatusReport.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </SectionCard>
      </div>

      {/* Top products */}
      <SectionCard title={t.topProducts}>
        <div className="h-72 px-2 py-4">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={topProductsReport} margin={{ left: 0, right: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis dataKey="name" tick={{ fontSize: 10, fill: '#94a3b8' }} axisLine={false} tickLine={false} angle={-15} textAnchor="end" height={60} />
              <YAxis tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ borderRadius: '8px', border: '1px solid #e2e8f0', fontSize: '13px' }} formatter={(v: number, name: string) => name === 'revenue' ? [formatKM(v, lang), t.revenue] : [v, t.unitsSold]} />
              <Legend formatter={(v) => v === 'revenue' ? t.revenue : t.unitsSold} />
              <Bar dataKey="revenue" fill="#2563eb" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </SectionCard>
    </div>
  );
}
