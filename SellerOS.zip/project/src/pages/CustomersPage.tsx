import { useState, useMemo } from 'react';
import { UserPlus, Users, Mail, Phone, ArrowRight } from 'lucide-react';
import { PageHeader } from '@/components/PageHeader';
import { FilterBar, type FilterOption } from '@/components/FilterBar';
import { ChannelBadge } from '@/components/Badges';
import { Table, THead, TBody, TR, TH, TD } from '@/components/Table';
import { EmptyState } from '@/components/EmptyState';
import { useI18n } from '@/locales';
import { formatKM, formatDate, classNames } from '@/utils/format';
import { mockCustomers } from '@/data/customers';
import type { Customer, SalesChannel } from '@/types';
import type { Route } from '@/hooks/useRouter';

interface CustomersPageProps {
  navigate: (route: Route) => void;
}

type SortField = 'name' | 'orderCount' | 'totalSpent' | 'lastOrderDate';
type SortDir = 'asc' | 'desc';

export function CustomersPage({ navigate }: CustomersPageProps) {
  const { t, lang } = useI18n();
  const [search, setSearch] = useState('');
  const [channelFilter, setChannelFilter] = useState('');
  const [sortField, setSortField] = useState<SortField>('totalSpent');
  const [sortDir, setSortDir] = useState<SortDir>('desc');

  const channelOptions: FilterOption[] = (['olx', 'instagram', 'facebook', 'webshop'] as SalesChannel[]).map((c) => ({
    value: c, label: t[`ch_${c}` as keyof typeof t] as string,
  }));

  const filtered = useMemo(() => {
    let result: Customer[] = mockCustomers.filter((c) => {
      const matchesSearch = !search ||
        c.name.toLowerCase().includes(search.toLowerCase()) ||
        c.email.toLowerCase().includes(search.toLowerCase());
      const matchesChannel = !channelFilter || c.primaryChannel === channelFilter;
      return matchesSearch && matchesChannel;
    });
    result = result.sort((a, b) => {
      let cmp = 0;
      switch (sortField) {
        case 'name': cmp = a.name.localeCompare(b.name); break;
        case 'orderCount': cmp = a.orderCount - b.orderCount; break;
        case 'totalSpent': cmp = a.totalSpent - b.totalSpent; break;
        case 'lastOrderDate': cmp = new Date(a.lastOrderDate).getTime() - new Date(b.lastOrderDate).getTime(); break;
      }
      return sortDir === 'asc' ? cmp : -cmp;
    });
    return result;
  }, [search, channelFilter, sortField, sortDir]);

  const handleSort = (field: SortField) => {
    if (sortField === field) setSortDir((d) => d === 'asc' ? 'desc' : 'asc');
    else { setSortField(field); setSortDir('desc'); }
  };

  const clearFilters = () => { setSearch(''); setChannelFilter(''); };

  return (
    <div>
      <PageHeader
        title={t.customers}
        subtitle={`${filtered.length} ${t.resultsCount}`}
        actions={<button className="btn-primary"><UserPlus className="h-4 w-4" /> {t.newCustomer}</button>}
      />

      <div className="card shadow-card p-4">
        <FilterBar
          searchValue={search}
          onSearchChange={setSearch}
          searchPlaceholder={t.search}
          onClear={clearFilters}
          filters={[
            { key: 'channel', value: channelFilter, onChange: setChannelFilter, options: channelOptions, placeholder: t.allChannels },
          ]}
        />
      </div>

      <div className="card shadow-card mt-4 overflow-hidden">
        {filtered.length === 0 ? (
          <EmptyState icon={Users} title={t.noResults} description={t.noResultsDesc}
            action={<button onClick={clearFilters} className="btn-secondary">{t.clearFilters}</button>} />
        ) : (
          <Table>
            <THead>
              <TR>
                <TH sortable active={sortField === 'name'} direction={sortDir} onClick={() => handleSort('name')}>{t.customer}</TH>
                <TH>{t.email}</TH>
                <TH>{t.phone}</TH>
                <TH sortable active={sortField === 'orderCount'} direction={sortDir} onClick={() => handleSort('orderCount')}>{t.orderCount}</TH>
                <TH sortable active={sortField === 'totalSpent'} direction={sortDir} onClick={() => handleSort('totalSpent')}>{t.totalSpent}</TH>
                <TH sortable active={sortField === 'lastOrderDate'} direction={sortDir} onClick={() => handleSort('lastOrderDate')}>{t.lastOrder}</TH>
                <TH>{t.primaryChannel}</TH>
              </TR>
            </THead>
            <TBody>
              {filtered.map((c) => (
                <TR key={c.id} onClick={() => navigate({ name: 'customer-detail', id: c.id })}>
                  <TD>
                    <div className="flex items-center gap-3">
                      <div className="flex h-9 w-9 items-center justify-center rounded-full bg-slate-200 text-xs font-semibold text-slate-600">
                        {c.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}
                      </div>
                      <div>
                        <p className="font-medium text-slate-900">{c.name}</p>
                        <p className="text-xs text-slate-400">{c.city}</p>
                      </div>
                    </div>
                  </TD>
                  <TD className="text-slate-600">{c.email}</TD>
                  <TD className="text-slate-600">{c.phone}</TD>
                  <TD className="tnum font-medium">{c.orderCount}</TD>
                  <TD className="tnum font-semibold">{formatKM(c.totalSpent, lang)}</TD>
                  <TD className="text-slate-500">{formatDate(c.lastOrderDate, lang)}</TD>
                  <TD><ChannelBadge channel={c.primaryChannel} /></TD>
                </TR>
              ))}
            </TBody>
          </Table>
        )}
      </div>
    </div>
  );
}
