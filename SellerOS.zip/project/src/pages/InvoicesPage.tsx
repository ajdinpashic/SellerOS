import { useState, useMemo } from 'react';
import { FileText, Eye, Download, Send, Plus } from 'lucide-react';
import { PageHeader } from '@/components/PageHeader';
import { FilterBar, type FilterOption } from '@/components/FilterBar';
import { InvoiceStatusBadge } from '@/components/Badges';
import { Modal } from '@/components/Modal';
import { EmptyState } from '@/components/EmptyState';
import { useI18n } from '@/locales';
import { formatKM, formatDate } from '@/utils/format';
import { mockInvoices } from '@/data/misc';
import type { InvoiceStatus, Invoice } from '@/types';

export function InvoicesPage() {
  const { t, lang } = useI18n();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [previewInvoice, setPreviewInvoice] = useState<Invoice | null>(null);
  const [toast, setToast] = useState('');

  const statusOptions: FilterOption[] = (['draft', 'sent', 'paid', 'overdue'] as InvoiceStatus[]).map((s) => ({
    value: s, label: t[`inv_${s}` as keyof typeof t] as string,
  }));

  const filtered = useMemo(() => {
    return mockInvoices.filter((inv) => {
      const matchesSearch = !search ||
        inv.id.toLowerCase().includes(search.toLowerCase()) ||
        inv.customerName.toLowerCase().includes(search.toLowerCase()) ||
        inv.orderId.toLowerCase().includes(search.toLowerCase());
      const matchesStatus = !statusFilter || inv.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [search, statusFilter]);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(''), 2500);
  };

  return (
    <div>
      <PageHeader
        title={t.invoices}
        subtitle={`${filtered.length} ${t.resultsCount}`}
        actions={<button className="btn-primary"><Plus className="h-4 w-4" /> {t.createInvoice}</button>}
      />

      <div className="card shadow-card p-4">
        <FilterBar
          searchValue={search}
          onSearchChange={setSearch}
          searchPlaceholder={t.search}
          onClear={() => { setSearch(''); setStatusFilter(''); }}
          filters={[
            { key: 'status', value: statusFilter, onChange: setStatusFilter, options: statusOptions, placeholder: t.allStatuses },
          ]}
        />
      </div>

      <div className="card shadow-card mt-4 overflow-hidden">
        {filtered.length === 0 ? (
          <EmptyState icon={FileText} title={t.noResults} description={t.noResultsDesc} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b border-slate-200 bg-slate-50/50">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">{t.invoice}</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">{t.invoiceOrder}</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">{t.customer}</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">{t.invoiceAmount}</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">{t.invoiceStatus}</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">{t.invoiceDate}</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-slate-500">{t.actions}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((inv) => (
                  <tr key={inv.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-4 py-3.5 font-medium text-slate-900 whitespace-nowrap">{inv.id}</td>
                    <td className="px-4 py-3.5 text-slate-600 whitespace-nowrap">{inv.orderId}</td>
                    <td className="px-4 py-3.5 text-slate-700 whitespace-nowrap">{inv.customerName}</td>
                    <td className="px-4 py-3.5 font-semibold tnum whitespace-nowrap">{formatKM(inv.amount, lang)}</td>
                    <td className="px-4 py-3.5 whitespace-nowrap"><InvoiceStatusBadge status={inv.status} /></td>
                    <td className="px-4 py-3.5 text-slate-500 whitespace-nowrap">{formatDate(inv.date, lang)}</td>
                    <td className="px-4 py-3.5">
                      <div className="flex items-center justify-end gap-1">
                        <button onClick={() => setPreviewInvoice(inv)} className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-700" title={t.preview}>
                          <Eye className="h-4 w-4" />
                        </button>
                        <button onClick={() => showToast(`PDF: ${inv.id}`)} className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-700" title={t.download}>
                          <Download className="h-4 w-4" />
                        </button>
                        <button onClick={() => showToast(`${t.sendInvoice}: ${inv.id}`)} className="rounded-lg p-1.5 text-slate-500 hover:bg-blue-50 hover:text-blue-600" title={t.sendInvoice}>
                          <Send className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Preview modal */}
      <Modal
        open={!!previewInvoice}
        onClose={() => setPreviewInvoice(null)}
        title={previewInvoice?.id}
        description={previewInvoice ? `${previewInvoice.orderId} · ${previewInvoice.customerName}` : ''}
        size="lg"
        footer={
          <>
            <button onClick={() => previewInvoice && showToast(`PDF: ${previewInvoice.id}`)} className="btn-secondary">
              <Download className="h-4 w-4" /> {t.download}
            </button>
            <button onClick={() => previewInvoice && showToast(`${t.sendInvoice}: ${previewInvoice.id}`)} className="btn-primary">
              <Send className="h-4 w-4" /> {t.sendInvoice}
            </button>
          </>
        }
      >
        {previewInvoice && (
          <div className="space-y-4">
            <div className="flex items-start justify-between rounded-lg border border-slate-200 p-5">
              <div>
                <p className="text-xs text-slate-400 uppercase tracking-wider">{t.invoice}</p>
                <p className="text-lg font-bold text-slate-900">{previewInvoice.id}</p>
              </div>
              <InvoiceStatusBadge status={previewInvoice.status} />
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="rounded-lg bg-slate-50 p-4">
                <p className="text-xs text-slate-400 uppercase tracking-wider mb-1">{t.customer}</p>
                <p className="font-medium text-slate-900">{previewInvoice.customerName}</p>
              </div>
              <div className="rounded-lg bg-slate-50 p-4">
                <p className="text-xs text-slate-400 uppercase tracking-wider mb-1">{t.invoiceOrder}</p>
                <p className="font-medium text-slate-900">{previewInvoice.orderId}</p>
              </div>
              <div className="rounded-lg bg-slate-50 p-4">
                <p className="text-xs text-slate-400 uppercase tracking-wider mb-1">{t.invoiceDate}</p>
                <p className="font-medium text-slate-900">{formatDate(previewInvoice.date, lang)}</p>
              </div>
              <div className="rounded-lg bg-blue-50 p-4">
                <p className="text-xs text-blue-400 uppercase tracking-wider mb-1">{t.invoiceAmount}</p>
                <p className="text-xl font-bold text-slate-900 tnum">{formatKM(previewInvoice.amount, lang)}</p>
              </div>
            </div>
          </div>
        )}
      </Modal>

      {toast && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 rounded-lg bg-slate-900 px-4 py-3 text-sm text-white shadow-popover animate-slide-up z-50">
          {toast}
        </div>
      )}
    </div>
  );
}
