import { useState } from 'react';
import {
  ArrowLeft, MapPin, Phone, Mail, User, Package, Truck,
  CheckCircle2, Circle, XCircle, Clock, StickyNote,
} from 'lucide-react';
import { PageHeader } from '@/components/PageHeader';
import { OrderStatusBadge, ChannelBadge, PaymentBadge } from '@/components/Badges';
import { Modal } from '@/components/Modal';
import { useI18n } from '@/locales';
import { formatKM, formatDate, formatDateTime, orderSubtotal, orderTotal, classNames } from '@/utils/format';
import { mockOrders } from '@/data/orders';
import { mockCustomers } from '@/data/customers';
import type { Order, OrderStatus } from '@/types';
import type { Route } from '@/hooks/useRouter';

interface OrderDetailPageProps {
  orderId: string;
  navigate: (route: Route) => void;
}

const statusFlow: { status: Order['timeline'][number]['status']; labelKey: string }[] = [
  { status: 'received', labelKey: 'tl_received' },
  { status: 'confirmed', labelKey: 'tl_confirmed' },
  { status: 'ready', labelKey: 'tl_packing' },
  { status: 'shipped', labelKey: 'tl_shipped' },
  { status: 'delivered', labelKey: 'tl_delivered' },
];

const statusOrder: Record<OrderStatus, number> = {
  pending: 0, confirmed: 1, ready: 2, shipped: 3, delivered: 4, cancelled: 1,
};

export function OrderDetailPage({ orderId, navigate }: OrderDetailPageProps) {
  const { t, lang } = useI18n();
  const [order, setOrder] = useState<Order | undefined>(mockOrders.find((o) => o.id === orderId));
  const [cancelModalOpen, setCancelModalOpen] = useState(false);

  if (!order) {
    return (
      <div>
        <PageHeader title={t.orderNumber} breadcrumb={[{ label: t.orders, onClick: () => navigate({ name: 'orders' }) }, { label: orderId }]} />
        <div className="card p-12 text-center text-slate-500">{t.noOrders}</div>
      </div>
    );
  }

  const customer = mockCustomers.find((c) => c.id === order.customerId);
  const customerOrders = mockOrders.filter((o) => o.customerId === order.customerId && o.id !== order.id);
  const subtotal = orderSubtotal(order.items);
  const total = orderTotal(order.items, order.shipping);
  const currentStep = statusOrder[order.status];

  const advanceStatus = (next: OrderStatus) => {
    const newTimeline = order.timeline.map((e, i) => ({
      ...e,
      done: i <= statusOrder[next],
    }));
    setOrder({ ...order, status: next, timeline: newTimeline });
  };

  const cancelOrder = () => {
    setOrder({ ...order, status: 'cancelled' });
    setCancelModalOpen(false);
  };

  const isCancelled = order.status === 'cancelled';

  return (
    <div>
      <PageHeader
        title={`${t.orderNumber} ${order.id}`}
        breadcrumb={[
          { label: t.orders, onClick: () => navigate({ name: 'orders' }) },
          { label: order.id },
        ]}
        actions={
          <button onClick={() => navigate({ name: 'orders' })} className="btn-secondary">
            <ArrowLeft className="h-4 w-4" />
            {t.backToOrders}
          </button>
        }
      />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        {/* Left: items + timeline */}
        <div className="lg:col-span-2 space-y-4">
          {/* Order items */}
          <div className="card shadow-card overflow-hidden">
            <div className="border-b border-slate-100 px-5 py-4">
              <h3 className="text-base font-semibold text-slate-900">{t.orderItems}</h3>
            </div>
            <div className="divide-y divide-slate-100">
              {order.items.map((item, i) => (
                <div key={i} className="flex items-center justify-between px-5 py-4">
                  <div className="flex items-center gap-3">
                    <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-slate-100">
                      <Package className="h-5 w-5 text-slate-400" />
                    </div>
                    <div>
                      <p className="font-medium text-slate-900">{item.name}</p>
                      {item.variant && <p className="text-sm text-slate-500">{item.variant}</p>}
                      <p className="text-sm text-slate-400 mt-0.5">{item.quantity} × {formatKM(item.price, lang)}</p>
                    </div>
                  </div>
                  <p className="font-semibold text-slate-900 tnum">{formatKM(item.quantity * item.price, lang)}</p>
                </div>
              ))}
            </div>
            {/* Totals */}
            <div className="border-t border-slate-100 bg-slate-50/50 px-5 py-4 space-y-2">
              <div className="flex justify-between text-sm text-slate-600">
                <span>{t.subtotal}</span>
                <span className="tnum">{formatKM(subtotal, lang)}</span>
              </div>
              <div className="flex justify-between text-sm text-slate-600">
                <span>{t.shippingCost}</span>
                <span className="tnum">{formatKM(order.shipping, lang)}</span>
              </div>
              <div className="flex justify-between border-t border-slate-200 pt-2 text-base font-bold text-slate-900">
                <span>{t.total}</span>
                <span className="tnum">{formatKM(total, lang)}</span>
              </div>
            </div>
          </div>

          {/* Order status timeline */}
          <div className="card shadow-card overflow-hidden">
            <div className="border-b border-slate-100 px-5 py-4">
              <h3 className="text-base font-semibold text-slate-900">{t.orderTimeline}</h3>
            </div>
            <div className="px-5 py-6">
              {isCancelled ? (
                <div className="flex items-center gap-3 rounded-lg bg-red-50 px-4 py-3 border border-red-200">
                  <XCircle className="h-5 w-5 text-red-500" />
                  <span className="text-sm font-medium text-red-700">{t.tl_cancelled}</span>
                </div>
              ) : (
                <div className="relative">
                  {statusFlow.map((step, i) => {
                    const done = i <= currentStep;
                    const isLast = i === statusFlow.length - 1;
                    return (
                      <div key={step.status} className="flex gap-3">
                        <div className="flex flex-col items-center">
                          {done ? (
                            <CheckCircle2 className="h-6 w-6 text-emerald-500" />
                          ) : (
                            <Circle className="h-6 w-6 text-slate-300" />
                          )}
                          {!isLast && (
                            <div className={classNames('w-0.5 flex-1 min-h-[2rem]', done ? 'bg-emerald-200' : 'bg-slate-200')} />
                          )}
                        </div>
                        <div className={classNames('pb-6', !isLast && 'min-h-[2.5rem]')}>
                          <p className={classNames('text-sm font-medium', done ? 'text-slate-900' : 'text-slate-400')}>
                            {t[step.labelKey as keyof typeof t] as string}
                          </p>
                          {done && order.timeline[i] && (
                            <p className="text-xs text-slate-400 mt-0.5">{formatDateTime(order.timeline[i].timestamp, lang)}</p>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* Order note */}
          {order.note && (
            <div className="card shadow-card p-5">
              <div className="flex items-start gap-3">
                <StickyNote className="h-5 w-5 text-amber-500 mt-0.5" />
                <div>
                  <p className="text-sm font-semibold text-slate-900">{t.orderNote}</p>
                  <p className="mt-1 text-sm text-slate-600">{order.note}</p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Right: customer info + actions */}
        <div className="space-y-4">
          {/* Order actions */}
          <div className="card shadow-card p-5">
            <h3 className="text-base font-semibold text-slate-900 mb-4">{t.actions}</h3>
            <div className="space-y-2">
              {order.status === 'pending' && (
                <button onClick={() => advanceStatus('confirmed')} className="btn-primary w-full">
                  <CheckCircle2 className="h-4 w-4" /> {t.confirm}
                </button>
              )}
              {order.status === 'confirmed' && (
                <button onClick={() => advanceStatus('ready')} className="btn-primary w-full">
                  <Package className="h-4 w-4" /> {t.prepare}
                </button>
              )}
              {order.status === 'ready' && (
                <button onClick={() => advanceStatus('shipped')} className="btn-primary w-full">
                  <Truck className="h-4 w-4" /> {t.ship}
                </button>
              )}
              {order.status === 'shipped' && (
                <button onClick={() => advanceStatus('delivered')} className="btn-primary w-full">
                  <CheckCircle2 className="h-4 w-4" /> {t.markDelivered}
                </button>
              )}
              {!isCancelled && order.status !== 'delivered' && (
                <button onClick={() => setCancelModalOpen(true)} className="btn-secondary w-full text-red-600 hover:bg-red-50 hover:border-red-200">
                  <XCircle className="h-4 w-4" /> {t.cancel}
                </button>
              )}
              {isCancelled && (
                <p className="text-sm text-slate-500 text-center py-2">{t.tl_cancelled}</p>
              )}
            </div>
          </div>

          {/* Customer info */}
          <div className="card shadow-card p-5">
            <h3 className="text-base font-semibold text-slate-900 mb-4">{t.customerInfo}</h3>
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-slate-100">
                  <User className="h-5 w-5 text-slate-500" />
                </div>
                <div>
                  <button
                    onClick={() => customer && navigate({ name: 'customer-detail', id: customer.id })}
                    className="font-medium text-slate-900 hover:text-blue-600"
                  >
                    {order.customerName}
                  </button>
                  <p className="text-xs text-slate-400">{customer?.city}</p>
                </div>
              </div>
              <div className="flex items-center gap-2.5 text-sm text-slate-600">
                <Phone className="h-4 w-4 text-slate-400" /> {order.phone}
              </div>
              <div className="flex items-center gap-2.5 text-sm text-slate-600">
                <Mail className="h-4 w-4 text-slate-400" /> {order.email}
              </div>
              <div className="flex items-start gap-2.5 text-sm text-slate-600">
                <MapPin className="h-4 w-4 text-slate-400 mt-0.5" /> {order.address}
              </div>
            </div>
            <div className="mt-4 pt-4 border-t border-slate-100 flex flex-wrap gap-2">
              <ChannelBadge channel={order.channel} />
              <PaymentBadge method={order.paymentMethod} />
              <OrderStatusBadge status={order.status} />
            </div>
          </div>

          {/* Previous orders */}
          {customerOrders.length > 0 && (
            <div className="card shadow-card p-5">
              <h3 className="text-base font-semibold text-slate-900 mb-3">{t.previousOrders}</h3>
              <div className="space-y-2">
                {customerOrders.slice(0, 4).map((o) => (
                  <button
                    key={o.id}
                    onClick={() => navigate({ name: 'order-detail', id: o.id })}
                    className="flex w-full items-center justify-between rounded-lg border border-slate-100 px-3 py-2.5 text-left hover:bg-slate-50 transition-colors"
                  >
                    <div>
                      <span className="text-sm font-medium text-slate-900">{o.id}</span>
                      <span className="ml-2 text-xs text-slate-400">{formatDate(o.date, lang)}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium tnum">{formatKM(orderTotal(o.items, o.shipping), lang)}</span>
                      <OrderStatusBadge status={o.status} />
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      <Modal
        open={cancelModalOpen}
        onClose={() => setCancelModalOpen(false)}
        title={t.cancel}
        description={`${t.orderNumber} ${order.id}`}
        footer={
          <>
            <button onClick={() => setCancelModalOpen(false)} className="btn-secondary">{t.cancelBtn}</button>
            <button onClick={cancelOrder} className="btn-danger">{t.cancel}</button>
          </>
        }
      >
        <p className="text-sm text-slate-600">Da li ste sigurni da želite otkazati ovu narudžbu? Ova akcija ne može biti poništena.</p>
      </Modal>
    </div>
  );
}
