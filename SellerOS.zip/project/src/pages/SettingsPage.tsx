import { useState } from 'react';
import {
  User, Building2, Globe, Bell, Users as UsersIcon, CreditCard, Shield,
  Check, Mail, Smartphone, Crown,
} from 'lucide-react';
import { PageHeader } from '@/components/PageHeader';
import { useI18n } from '@/locales';
import { LanguageSwitcher } from '@/components/LanguageSwitcher';
import { classNames } from '@/utils/format';

type SettingsTab = 'profile' | 'company' | 'language' | 'notifications' | 'users' | 'subscription' | 'security';

const tabs: { key: SettingsTab; labelKey: string; icon: typeof User }[] = [
  { key: 'profile', labelKey: 'profileSettings', icon: User },
  { key: 'company', labelKey: 'companySettings', icon: Building2 },
  { key: 'language', labelKey: 'languageSettings', icon: Globe },
  { key: 'notifications', labelKey: 'notificationSettings', icon: Bell },
  { key: 'users', labelKey: 'usersSettings', icon: UsersIcon },
  { key: 'subscription', labelKey: 'subscriptionSettings', icon: CreditCard },
  { key: 'security', labelKey: 'securitySettings', icon: Shield },
];

const teamMembers = [
  { name: 'Edin Horozović', email: 'edin@shopos.ba', role: 'admin' },
  { name: 'Amra Selimović', email: 'amra@shopos.ba', role: 'manager' },
  { name: 'Haris Mujagić', email: 'haris@shopos.ba', role: 'staff' },
];

export function SettingsPage() {
  const { t } = useI18n();
  const [activeTab, setActiveTab] = useState<SettingsTab>('profile');
  const [notifPrefs, setNotifPrefs] = useState({ email: true, push: false, orders: true, lowStock: true });
  const [savedToast, setSavedToast] = useState(false);

  const handleSave = () => {
    setSavedToast(true);
    setTimeout(() => setSavedToast(false), 2500);
  };

  const toggleNotif = (key: keyof typeof notifPrefs) => {
    setNotifPrefs((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div>
      <PageHeader title={t.settings} />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-4">
        {/* Tab sidebar */}
        <div className="lg:col-span-1">
          <div className="card shadow-card p-2">
            <nav className="space-y-0.5">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.key}
                    onClick={() => setActiveTab(tab.key)}
                    className={classNames(
                      'flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors',
                      activeTab === tab.key ? 'bg-blue-50 text-blue-700' : 'text-slate-600 hover:bg-slate-50',
                    )}
                  >
                    <Icon className="h-4 w-4" />
                    {t[tab.labelKey as keyof typeof t] as string}
                  </button>
                );
              })}
            </nav>
          </div>
        </div>

        {/* Tab content */}
        <div className="lg:col-span-3">
          <div className="card shadow-card p-6">
            {activeTab === 'profile' && (
              <div className="space-y-5 max-w-lg">
                <h3 className="text-base font-semibold text-slate-900">{t.profileSettings}</h3>
                <div className="flex items-center gap-4">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-blue-500 to-blue-700 text-white text-xl font-bold">EH</div>
                  <button className="btn-secondary">{t.profile}</button>
                </div>
                <div>
                  <label className="label">{t.fullName}</label>
                  <input className="input" defaultValue="Edin Horozović" />
                </div>
                <div>
                  <label className="label">{t.emailAddress}</label>
                  <input className="input" defaultValue="edin@shopos.ba" />
                </div>
                <div>
                  <label className="label">{t.phone}</label>
                  <input className="input" defaultValue="+387 61 234 567" />
                </div>
                <button onClick={handleSave} className="btn-primary">{t.saveChanges}</button>
              </div>
            )}

            {activeTab === 'company' && (
              <div className="space-y-5 max-w-lg">
                <h3 className="text-base font-semibold text-slate-900">{t.companySettings}</h3>
                <div>
                  <label className="label">{t.companyName}</label>
                  <input className="input" defaultValue="ShopOS d.o.o. Sarajevo" />
                </div>
                <div>
                  <label className="label">{t.companyAddress}</label>
                  <input className="input" defaultValue="Ferhadija 12, 71000 Sarajevo" />
                </div>
                <div>
                  <label className="label">{t.vatNumber}</label>
                  <input className="input" defaultValue="1234567890123" />
                </div>
                <button onClick={handleSave} className="btn-primary">{t.saveChanges}</button>
              </div>
            )}

            {activeTab === 'language' && (
              <div className="space-y-5 max-w-lg">
                <h3 className="text-base font-semibold text-slate-900">{t.languageSettings}</h3>
                <p className="text-sm text-slate-500">{t.selectLanguage}</p>
                <div className="flex items-center gap-3">
                  <LanguageSwitcher />
                </div>
                <div className="rounded-lg bg-slate-50 p-4 text-sm text-slate-500">
                  {t.saved}: localStorage
                </div>
              </div>
            )}

            {activeTab === 'notifications' && (
              <div className="space-y-4 max-w-lg">
                <h3 className="text-base font-semibold text-slate-900">{t.notificationSettings}</h3>
                {[
                  { key: 'email' as const, label: t.emailNotifications, icon: Mail },
                  { key: 'push' as const, label: t.pushNotifications, icon: Smartphone },
                  { key: 'orders' as const, label: t.orderNotifications, icon: Bell },
                  { key: 'lowStock' as const, label: t.lowStockAlerts, icon: Bell },
                ].map((item) => {
                  const Icon = item.icon;
                  const enabled = notifPrefs[item.key];
                  return (
                    <div key={item.key} className="flex items-center justify-between rounded-lg border border-slate-200 p-4">
                      <div className="flex items-center gap-3">
                        <Icon className="h-5 w-5 text-slate-400" />
                        <span className="text-sm font-medium text-slate-700">{item.label}</span>
                      </div>
                      <button
                        onClick={() => toggleNotif(item.key)}
                        className={classNames(
                          'relative h-6 w-11 rounded-full transition-colors',
                          enabled ? 'bg-blue-600' : 'bg-slate-200',
                        )}
                      >
                        <span className={classNames(
                          'absolute top-0.5 h-5 w-5 rounded-full bg-white shadow-sm transition-transform',
                          enabled ? 'translate-x-5' : 'translate-x-0.5',
                        )} />
                      </button>
                    </div>
                  );
                })}
                <button onClick={handleSave} className="btn-primary">{t.saveChanges}</button>
              </div>
            )}

            {activeTab === 'users' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-semibold text-slate-900">{t.teamMembers}</h3>
                  <button className="btn-primary"><UsersIcon className="h-4 w-4" /> {t.inviteMember}</button>
                </div>
                <div className="space-y-2">
                  {teamMembers.map((m) => (
                    <div key={m.email} className="flex items-center justify-between rounded-lg border border-slate-200 p-4">
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-slate-200 text-sm font-semibold text-slate-600">
                          {m.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}
                        </div>
                        <div>
                          <p className="font-medium text-slate-900">{m.name}</p>
                          <p className="text-sm text-slate-400">{m.email}</p>
                        </div>
                      </div>
                      <span className={classNames(
                        'inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium',
                        m.role === 'admin' ? 'bg-blue-50 text-blue-700' : m.role === 'manager' ? 'bg-purple-50 text-purple-700' : 'bg-slate-100 text-slate-600',
                      )}>
                        {t[m.role as keyof typeof t] as string}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'subscription' && (
              <div className="space-y-4 max-w-lg">
                <h3 className="text-base font-semibold text-slate-900">{t.subscriptionSettings}</h3>
                <div className="rounded-xl border-2 border-blue-500 bg-blue-50/50 p-5">
                  <div className="flex items-center gap-2 mb-2">
                    <Crown className="h-5 w-5 text-blue-600" />
                    <span className="font-semibold text-slate-900">{t.currentPlan}: Pro</span>
                  </div>
                  <p className="text-2xl font-bold text-slate-900">49 KM <span className="text-sm font-normal text-slate-400">/ mjesec</span></p>
                  <ul className="mt-4 space-y-1.5 text-sm text-slate-600">
                    {['Neograničene narudžbe', 'Sve integracije', 'Neograničeni kupci', 'Prioritetna podrška'].map((f) => (
                      <li key={f} className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-emerald-500" /> {f}
                      </li>
                    ))}
                  </ul>
                  <button onClick={handleSave} className="btn-primary mt-4">{t.upgrade}</button>
                </div>
              </div>
            )}

            {activeTab === 'security' && (
              <div className="space-y-4 max-w-lg">
                <h3 className="text-base font-semibold text-slate-900">{t.securitySettings}</h3>
                <div className="flex items-center justify-between rounded-lg border border-slate-200 p-4">
                  <div className="flex items-center gap-3">
                    <Shield className="h-5 w-5 text-slate-400" />
                    <span className="text-sm font-medium text-slate-700">{t.twoFactor}</span>
                  </div>
                  <button className="relative h-6 w-11 rounded-full bg-slate-200">
                    <span className="absolute top-0.5 h-5 w-5 rounded-full bg-white shadow-sm translate-x-0.5" />
                  </button>
                </div>
                <div>
                  <label className="label">{t.changePassword}</label>
                  <input type="password" className="input" placeholder="••••••••" />
                </div>
                <button onClick={handleSave} className="btn-primary">{t.saveChanges}</button>
              </div>
            )}
          </div>
        </div>
      </div>

      {savedToast && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 rounded-lg bg-slate-900 px-4 py-3 text-sm text-white shadow-popover animate-slide-up z-50">
          {t.saved}
        </div>
      )}
    </div>
  );
}
