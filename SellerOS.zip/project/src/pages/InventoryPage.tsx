import { useState, useMemo } from 'react';
import { Boxes, DollarSign, AlertTriangle, CircleSlash, Plus, Minus, Package } from 'lucide-react';
import { PageHeader } from '@/components/PageHeader';
import { StatCard } from '@/components/MetricCard';
import { FilterBar } from '@/components/FilterBar';
import { Table, THead, TBody, TR, TH, TD } from '@/components/Table';
import { Modal } from '@/components/Modal';
import { EmptyState } from '@/components/EmptyState';
import { useI18n } from '@/locales';
import { formatKM, classNames } from '@/utils/format';
import { mockProducts } from '@/data/products';
import type { Product } from '@/types';

type StockStatus = 'all' | 'low' | 'out' | 'ok';

export function InventoryPage() {
  const { t, lang } = useI18n();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<StockStatus>('all');
  const [adjustProduct, setAdjustProduct] = useState<Product | null>(null);
  const [newStock, setNewStock] = useState(0);
  const [reason, setReason] = useState('reason_new');
  const [toast, setToast] = useState(false);
  const [products, setProducts] = useState(mockProducts);

  const stats = useMemo(() => {
    const totalProducts = products.length;
    const value = products.reduce((s, p) => s + p.stock * p.cost, 0);
    const low = products.filter((p) => p.stock > 0 && p.stock <= p.minimumStock).length;
    const out = products.filter((p) => p.stock === 0).length;
    return { totalProducts, value, low, out };
  }, [products]);

  const filtered = useMemo(() => {
    return products.filter((p) => {
      const matchesSearch = !search ||
        p.name.toLowerCase().includes(search.toLowerCase()) ||
        p.sku.toLowerCase().includes(search.toLowerCase());
      const matchesStatus =
        statusFilter === 'all' ? true :
        statusFilter === 'low' ? p.stock > 0 && p.stock <= p.minimumStock :
        statusFilter === 'out' ? p.stock === 0 :
        p.stock > p.minimumStock;
      return matchesSearch && matchesStatus;
    });
  }, [products, search, statusFilter]);

  const stockBadge = (p: Product) => {
    if (p.stock === 0) return { label: t.outOfStock, classes: 'bg-red-50 text-red-700' };
    if (p.stock <= p.minimumStock) return { label: t.lowStock, classes: 'bg-amber-50 text-amber-700' };
    return { label: t.active, classes: 'bg-emerald-50 text-emerald-700' };
  };

  const openAdjust = (p: Product) => {
    setAdjustProduct(p);
    setNewStock(p.stock);
    setReason('reason_new');
  };

  const handleAdjust = () => {
    if (!adjustProduct) return;
    setProducts((prev) => prev.map((p) => p.id === adjustProduct.id ? { ...p, stock: newStock } : p));
    setAdjustProduct(null);
    setToast(true);
    setTimeout(() => setToast(false), 2500);
  };

  return (
    <div>
      <PageHeader title={t.inventory} subtitle={`${filtered.length} ${t.resultsCount}`} />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4 mb-4">
        <StatCard label={t.totalProducts} value={`${stats.totalProducts}`} icon={Boxes} iconBg="bg-blue-50" />
        <StatCard label={t.inventoryValue} value={formatKM(stats.value, lang)} icon={DollarSign} iconBg="bg-emerald-50" />
        <StatCard label={t.lowStockCount} value={`${stats.low}`} icon={AlertTriangle} iconBg="bg-amber-50" />
        <StatCard label={t.outOfStock} value={`${stats.out}`} icon={CircleSlash} iconBg="bg-red-50" />
      </div>

      <div className="card shadow-card p-4">
        <FilterBar
          searchValue={search}
          onSearchChange={setSearch}
          searchPlaceholder={t.search}
          onClear={() => { setSearch(''); setStatusFilter('all'); }}
          filters={[
            { key: 'status', value: statusFilter, onChange: (v) => setStatusFilter(v as StockStatus), options: [
              { value: 'all', label: t.all },
              { value: 'low', label: t.lowStock },
              { value: 'out', label: t.outOfStock },
              { value: 'ok', label: t.active },
            ], placeholder: t.allStatuses },
          ]}
        />
      </div>

      <div className="card shadow-card mt-4 overflow-hidden">
        {filtered.length === 0 ? (
          <EmptyState icon={Package} title={t.noResults} description={t.noResultsDesc} />
        ) : (
          <Table>
            <THead>
              <TR>
                <TH>{t.product}</TH>
                <TH>{t.sku}</TH>
                <TH>{t.stock}</TH>
                <TH>{t.reserved}</TH>
                <TH>{t.available}</TH>
                <TH>{t.minimum}</TH>
                <TH>{t.status}</TH>
                <TH>{t.actions}</TH>
              </TR>
            </THead>
            <TBody>
              {filtered.map((p) => {
                const badge = stockBadge(p);
                const available = Math.max(p.stock - p.reserved, 0);
                return (
                  <TR key={p.id}>
                    <TD className="font-medium text-slate-900">{p.name}</TD>
                    <TD className="text-slate-500 font-mono text-xs">{p.sku}</TD>
                    <TD className={classNames('font-semibold tnum', p.stock === 0 ? 'text-red-600' : p.stock <= p.minimumStock ? 'text-amber-600' : 'text-slate-700')}>{p.stock}</TD>
                    <TD className="text-slate-500 tnum">{p.reserved}</TD>
                    <TD className="text-slate-700 tnum">{available}</TD>
                    <TD className="text-slate-500 tnum">{p.minimumStock}</TD>
                    <TD>
                      <span className={classNames('inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium', badge.classes)}>
                        {badge.label}
                      </span>
                    </TD>
                    <TD>
                      <button onClick={() => openAdjust(p)} className="btn-secondary text-xs py-1.5 px-2.5">
                        {t.adjust}
                      </button>
                    </TD>
                  </TR>
                );
              })}
            </TBody>
          </Table>
        )}
      </div>

      {/* Adjustment modal */}
      <Modal
        open={!!adjustProduct}
        onClose={() => setAdjustProduct(null)}
        title={t.adjustStock}
        description={adjustProduct?.name}
        footer={
          <>
            <button onClick={() => setAdjustProduct(null)} className="btn-secondary">{t.cancelBtn}</button>
            <button onClick={handleAdjust} className="btn-primary">{t.adjust}</button>
          </>
        }
      >
        {adjustProduct && (
          <div className="space-y-4">
            <div className="flex items-center justify-between rounded-lg bg-slate-50 px-4 py-3">
              <span className="text-sm text-slate-500">{t.stock}</span>
              <span className="text-lg font-bold text-slate-900 tnum">{adjustProduct.stock}</span>
            </div>
            <div>
              <label className="label">{t.newStock}</label>
              <div className="flex items-center gap-2">
                <button onClick={() => setNewStock((v) => Math.max(0, v - 1))} className="btn-secondary p-2">
                  <Minus className="h-4 w-4" />
                </button>
                <input type="number" min={0} className="input tnum text-center" value={newStock} onChange={(e) => setNewStock(parseInt(e.target.value) || 0)} />
                <button onClick={() => setNewStock((v) => v + 1)} className="btn-secondary p-2">
                  <Plus className="h-4 w-4" />
                </button>
              </div>
            </div>
            <div>
              <label className="label">{t.adjustmentReason}</label>
              <select className="input cursor-pointer" value={reason} onChange={(e) => setReason(e.target.value)}>
                <option value="reason_new">{t.reason_new}</option>
                <option value="reason_correction">{t.reason_correction}</option>
                <option value="reason_damage">{t.reason_damage}</option>
                <option value="reason_loss">{t.reason_loss}</option>
              </select>
            </div>
            <div className="flex items-center justify-between rounded-lg border border-slate-200 px-4 py-3">
              <span className="text-sm text-slate-500">{t.adjustment}</span>
              <span className={classNames('font-semibold tnum', newStock - adjustProduct.stock >= 0 ? 'text-emerald-600' : 'text-red-600')}>
                {newStock - adjustProduct.stock >= 0 ? '+' : ''}{newStock - adjustProduct.stock}
              </span>
            </div>
          </div>
        )}
      </Modal>

      {/* Toast */}
      {toast && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 rounded-lg bg-slate-900 px-4 py-3 text-sm text-white shadow-popover animate-slide-up z-50">
          {t.stockAdjusted}
        </div>
      )}
    </div>
  );
}
