import type { ReactNode } from 'react';
import { Search, X } from 'lucide-react';
import { classNames } from '@/utils/format';

export interface FilterOption {
  value: string;
  label: string;
}

interface FilterBarProps {
  searchValue: string;
  onSearchChange: (v: string) => void;
  searchPlaceholder?: string;
  filters?: {
    key: string;
    value: string;
    onChange: (v: string) => void;
    options: FilterOption[];
    placeholder?: string;
  }[];
  onClear?: () => void;
  actions?: ReactNode;
  className?: string;
}

export function FilterBar({
  searchValue, onSearchChange, searchPlaceholder = 'Search...',
  filters = [], onClear, actions, className,
}: FilterBarProps) {
  const hasActiveFilters = searchValue || filters.some((f) => f.value);

  return (
    <div className={classNames('flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between', className)}>
      <div className="flex flex-col gap-2 sm:flex-row sm:flex-wrap sm:items-center">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchValue}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder={searchPlaceholder}
            className="input pl-9 sm:w-56"
          />
        </div>
        {filters.map((f) => (
          <select
            key={f.key}
            value={f.value}
            onChange={(e) => f.onChange(e.target.value)}
            className="input sm:w-auto cursor-pointer"
          >
            <option value="">{f.placeholder || f.key}</option>
            {f.options.map((opt) => (
              <option key={opt.value} value={opt.value}>{opt.label}</option>
            ))}
          </select>
        ))}
        {hasActiveFilters && onClear && (
          <button
            onClick={onClear}
            className="btn-ghost text-sm text-slate-500"
          >
            <X className="h-4 w-4" />
            Clear
          </button>
        )}
      </div>
      {actions && <div className="flex items-center gap-2">{actions}</div>}
    </div>
  );
}
