import type { ReactNode } from 'react';
import type { LucideIcon } from 'lucide-react';
import { ArrowDownRight, ArrowUpRight } from 'lucide-react';
import { classNames } from '@/utils/format';

interface MetricCardProps {
  label: string;
  value: string;
  delta?: number;
  deltaLabel?: string;
  icon: LucideIcon;
  iconBg?: string;
}

export function MetricCard({ label, value, delta, deltaLabel, icon: Icon, iconBg = 'bg-blue-50' }: MetricCardProps) {
  const positive = (delta ?? 0) >= 0;
  return (
    <div className="card p-5 shadow-card transition-shadow hover:shadow-card-hover">
      <div className="flex items-start justify-between">
        <div className="min-w-0">
          <p className="text-sm font-medium text-slate-500">{label}</p>
          <p className="mt-2 text-2xl font-bold tracking-tight text-slate-900 tnum">{value}</p>
        </div>
        <div className={classNames('flex h-10 w-10 shrink-0 items-center justify-center rounded-lg', iconBg)}>
          <Icon className="h-5 w-5 text-slate-700" />
        </div>
      </div>
      {delta !== undefined && (
        <div className="mt-3 flex items-center gap-1.5">
          <span className={classNames(
            'inline-flex items-center gap-0.5 rounded-md px-1.5 py-0.5 text-xs font-semibold tnum',
            positive ? 'bg-emerald-50 text-emerald-700' : 'bg-red-50 text-red-700',
          )}>
            {positive ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
            {Math.abs(delta)}%
          </span>
          {deltaLabel && <span className="text-xs text-slate-400">{deltaLabel}</span>}
        </div>
      )}
    </div>
  );
}

interface StatCardProps {
  label: string;
  value: string;
  icon: LucideIcon;
  iconBg?: string;
  sublabel?: string;
}

export function StatCard({ label, value, icon: Icon, iconBg = 'bg-slate-100', sublabel }: StatCardProps) {
  return (
    <div className="card p-5 shadow-card">
      <div className="flex items-center gap-3">
        <div className={classNames('flex h-11 w-11 items-center justify-center rounded-lg', iconBg)}>
          <Icon className="h-5 w-5 text-slate-700" />
        </div>
        <div className="min-w-0">
          <p className="text-sm text-slate-500">{label}</p>
          <p className="text-xl font-bold text-slate-900 tnum">{value}</p>
          {sublabel && <p className="text-xs text-slate-400">{sublabel}</p>}
        </div>
      </div>
    </div>
  );
}

interface SectionCardProps {
  title: string;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
}

export function SectionCard({ title, action, children, className }: SectionCardProps) {
  return (
    <div className={classNames('card shadow-card', className)}>
      <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
        <h3 className="text-base font-semibold text-slate-900">{title}</h3>
        {action}
      </div>
      {children}
    </div>
  );
}
