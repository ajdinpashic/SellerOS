import type { ReactNode } from 'react';

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  actions?: ReactNode;
  breadcrumb?: { label: string; href?: string; onClick?: () => void }[];
}

export function PageHeader({ title, subtitle, actions, breadcrumb }: PageHeaderProps) {
  return (
    <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
      <div>
        {breadcrumb && (
          <nav className="mb-2 flex items-center gap-1.5 text-sm text-slate-500">
            {breadcrumb.map((bc, i) => (
              <span key={i} className="flex items-center gap-1.5">
                {bc.onClick ? (
                  <button onClick={bc.onClick} className="hover:text-slate-700 transition-colors">
                    {bc.label}
                  </button>
                ) : (
                  <span className={i === breadcrumb.length - 1 ? 'text-slate-900 font-medium' : ''}>{bc.label}</span>
                )}
                {i < breadcrumb.length - 1 && <span className="text-slate-300">/</span>}
              </span>
            ))}
          </nav>
        )}
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-slate-500">{subtitle}</p>}
      </div>
      {actions && <div className="flex items-center gap-2 shrink-0">{actions}</div>}
    </div>
  );
}
