import type { ReactNode } from 'react';
import { classNames } from '@/utils/format';

interface TableProps {
  children: ReactNode;
  className?: string;
}

export function Table({ children, className }: TableProps) {
  return (
    <div className={classNames('overflow-x-auto', className)}>
      <table className="w-full text-sm">{children}</table>
    </div>
  );
}

export function THead({ children }: { children: ReactNode }) {
  return (
    <thead className="border-b border-slate-200 bg-slate-50/50">
      {children}
    </thead>
  );
}

export function TH({ children, className, onClick, sortable, active, direction }: {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
  sortable?: boolean;
  active?: boolean;
  direction?: 'asc' | 'desc';
}) {
  return (
    <th
      onClick={onClick}
      className={classNames(
        'px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500 whitespace-nowrap',
        onClick && 'cursor-pointer select-none hover:text-slate-700',
        className,
      )}
    >
      <span className="inline-flex items-center gap-1">
        {children}
        {sortable && active && (
          <span className="text-slate-400">{direction === 'asc' ? '↑' : '↓'}</span>
        )}
      </span>
    </th>
  );
}

export function TBody({ children }: { children: ReactNode }) {
  return <tbody className="divide-y divide-slate-100">{children}</tbody>;
}

export function TR({ children, onClick, className }: { children: ReactNode; onClick?: () => void; className?: string }) {
  return (
    <tr
      onClick={onClick}
      className={classNames(
        'transition-colors',
        onClick && 'cursor-pointer hover:bg-slate-50',
        className,
      )}
    >
      {children}
    </tr>
  );
}

export function TD({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <td className={classNames('px-4 py-3.5 text-slate-700 whitespace-nowrap', className)}>
      {children}
    </td>
  );
}
