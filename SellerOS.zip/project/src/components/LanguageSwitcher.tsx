import { useState, useRef, useEffect } from 'react';
import { Check, Globe } from 'lucide-react';
import { useI18n } from '@/locales';
import type { LanguageCode } from '@/types';
import { classNames } from '@/utils/format';

const languages: { code: LanguageCode; label: string; full: string }[] = [
  { code: 'bs', label: 'BS', full: 'Bosanski' },
  { code: 'hr', label: 'HR', full: 'Hrvatski' },
  { code: 'sr', label: 'SR', full: 'Srpski' },
  { code: 'en', label: 'EN', full: 'English' },
];

export function LanguageSwitcher() {
  const { lang, setLang } = useI18n();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  const current = languages.find((l) => l.code === lang)!;

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2.5 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50 hover:border-slate-300 transition-colors"
      >
        <Globe className="h-4 w-4 text-slate-400" />
        <span className="font-semibold">{current.label}</span>
      </button>
      {open && (
        <div className="absolute right-0 mt-2 w-44 rounded-lg border border-slate-200 bg-white py-1 shadow-popover animate-slide-up z-50">
          {languages.map((l) => (
            <button
              key={l.code}
              onClick={() => { setLang(l.code); setOpen(false); }}
              className={classNames(
                'flex w-full items-center justify-between px-3 py-2 text-sm transition-colors',
                l.code === lang ? 'text-blue-600 bg-blue-50/50' : 'text-slate-700 hover:bg-slate-50',
              )}
            >
              <span>
                <span className="font-semibold">{l.label}</span>
                <span className="ml-2 text-slate-400">{l.full}</span>
              </span>
              {l.code === lang && <Check className="h-4 w-4" />}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
