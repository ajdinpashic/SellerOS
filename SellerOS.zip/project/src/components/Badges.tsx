import type { OrderStatus, PaymentMethod, SalesChannel, InvoiceStatus, ShipmentStatus } from '@/types';
import { useI18n } from '@/locales';
import { classNames } from '@/utils/format';

const statusConfig: Record<OrderStatus, { key: string; classes: string; dot: string }> = {
  pending:    { key: 'st_pending',    classes: 'bg-slate-100 text-slate-700 border-slate-200',  dot: 'bg-slate-400' },
  confirmed:  { key: 'st_confirmed',  classes: 'bg-blue-50 text-blue-700 border-blue-200',      dot: 'bg-blue-500' },
  ready:      { key: 'st_ready',      classes: 'bg-amber-50 text-amber-700 border-amber-200',    dot: 'bg-amber-500' },
  shipped:    { key: 'st_shipped',    classes: 'bg-indigo-50 text-indigo-700 border-indigo-200', dot: 'bg-indigo-500' },
  delivered:  { key: 'st_delivered',  classes: 'bg-emerald-50 text-emerald-700 border-emerald-200', dot: 'bg-emerald-500' },
  cancelled:  { key: 'st_cancelled',  classes: 'bg-red-50 text-red-700 border-red-200',         dot: 'bg-red-500' },
};

export function OrderStatusBadge({ status }: { status: OrderStatus }) {
  const { t } = useI18n();
  const cfg = statusConfig[status];
  return (
    <span className={classNames(
      'inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium whitespace-nowrap',
      cfg.classes,
    )}>
      <span className={classNames('h-1.5 w-1.5 rounded-full', cfg.dot)} />
      {t[cfg.key as keyof typeof t] as string}
    </span>
  );
}

const channelConfig: Record<SalesChannel, { key: string; classes: string; dot: string }> = {
  olx:       { key: 'ch_olx',       classes: 'bg-purple-50 text-purple-700 border-purple-200',  dot: 'bg-purple-500' },
  instagram: { key: 'ch_instagram', classes: 'bg-pink-50 text-pink-700 border-pink-200',       dot: 'bg-pink-500' },
  facebook:  { key: 'ch_facebook',  classes: 'bg-blue-50 text-blue-700 border-blue-200',       dot: 'bg-blue-500' },
  webshop:   { key: 'ch_webshop',   classes: 'bg-cyan-50 text-cyan-700 border-cyan-200',       dot: 'bg-cyan-500' },
};

export function ChannelBadge({ channel }: { channel: SalesChannel }) {
  const { t } = useI18n();
  const cfg = channelConfig[channel];
  return (
    <span className={classNames(
      'inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium whitespace-nowrap',
      cfg.classes,
    )}>
      <span className={classNames('h-1.5 w-1.5 rounded-full', cfg.dot)} />
      {t[cfg.key as keyof typeof t] as string}
    </span>
  );
}

const paymentConfig: Record<PaymentMethod, string> = {
  cod: 'pay_cod',
  paid: 'pay_paid',
  card: 'pay_card',
  other: 'pay_other',
};

export function PaymentBadge({ method }: { method: PaymentMethod }) {
  const { t } = useI18n();
  return (
    <span className="inline-flex items-center rounded-md bg-slate-50 px-2 py-1 text-xs font-medium text-slate-600 border border-slate-200">
      {t[paymentConfig[method] as keyof typeof t] as string}
    </span>
  );
}

const invoiceStatusConfig: Record<InvoiceStatus, { key: string; classes: string }> = {
  draft:   { key: 'inv_draft',   classes: 'bg-slate-100 text-slate-700 border-slate-200' },
  sent:    { key: 'inv_sent',    classes: 'bg-blue-50 text-blue-700 border-blue-200' },
  paid:    { key: 'inv_paid',    classes: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
  overdue: { key: 'inv_overdue', classes: 'bg-red-50 text-red-700 border-red-200' },
};

export function InvoiceStatusBadge({ status }: { status: InvoiceStatus }) {
  const { t } = useI18n();
  const cfg = invoiceStatusConfig[status];
  return (
    <span className={classNames(
      'inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-medium',
      cfg.classes,
    )}>
      {t[cfg.key as keyof typeof t] as string}
    </span>
  );
}

const shipmentStatusConfig: Record<ShipmentStatus, { key: string; classes: string; dot: string }> = {
  pending:   { key: 'awaitingShipment', classes: 'bg-amber-50 text-amber-700 border-amber-200',   dot: 'bg-amber-500' },
  shipped:   { key: 'shippedTab',       classes: 'bg-indigo-50 text-indigo-700 border-indigo-200', dot: 'bg-indigo-500' },
  delivered: { key: 'deliveredTab',     classes: 'bg-emerald-50 text-emerald-700 border-emerald-200', dot: 'bg-emerald-500' },
  problem:   { key: 'problem',          classes: 'bg-red-50 text-red-700 border-red-200',         dot: 'bg-red-500' },
};

export function ShipmentStatusBadge({ status }: { status: ShipmentStatus }) {
  const { t } = useI18n();
  const cfg = shipmentStatusConfig[status];
  return (
    <span className={classNames(
      'inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium',
      cfg.classes,
    )}>
      <span className={classNames('h-1.5 w-1.5 rounded-full', cfg.dot)} />
      {t[cfg.key as keyof typeof t] as string}
    </span>
  );
}

const integrationStatusConfig: Record<string, { key: string; classes: string; dot: string }> = {
  connected:    { key: 'int_connected',    classes: 'bg-emerald-50 text-emerald-700 border-emerald-200', dot: 'bg-emerald-500' },
  disconnected: { key: 'int_disconnected', classes: 'bg-slate-100 text-slate-600 border-slate-200',     dot: 'bg-slate-400' },
  error:        { key: 'int_error',        classes: 'bg-red-50 text-red-700 border-red-200',            dot: 'bg-red-500' },
  needs_auth:   { key: 'int_needs_auth',   classes: 'bg-amber-50 text-amber-700 border-amber-200',      dot: 'bg-amber-500' },
};

export function IntegrationStatusBadge({ status }: { status: string }) {
  const { t } = useI18n();
  const cfg = integrationStatusConfig[status];
  if (!cfg) return null;
  return (
    <span className={classNames(
      'inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium',
      cfg.classes,
    )}>
      <span className={classNames('h-1.5 w-1.5 rounded-full', cfg.dot)} />
      {t[cfg.key as keyof typeof t] as string}
    </span>
  );
}
