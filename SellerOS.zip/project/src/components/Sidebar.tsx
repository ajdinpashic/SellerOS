import { 
  LayoutDashboard, ShoppingCart, Package, Boxes, Users, 
  Truck, FileText, BarChart3, Plug, Settings, LifeBuoy, X
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { useI18n } from '@/locales';
import type { Route } from '@/hooks/useRouter';
import { classNames } from '@/utils/format';

interface SidebarProps {
  current: Route['name'];
  navigate: (route: Route) => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

interface NavItem {
  route: Route;
  icon: LucideIcon;
  labelKey: keyof ReturnType<typeof useI18n>['t'];
}

export function Sidebar({ current, navigate, mobileOpen, onCloseMobile }: SidebarProps) {
  const { t } = useI18n();

  const mainNav: NavItem[] = [
    { route: { name: 'dashboard' }, icon: LayoutDashboard, labelKey: 'dashboard' },
    { route: { name: 'orders' }, icon: ShoppingCart, labelKey: 'orders' },
    { route: { name: 'products' }, icon: Package, labelKey: 'products' },
    { route: { name: 'inventory' }, icon: Boxes, labelKey: 'inventory' },
    { route: { name: 'customers' }, icon: Users, labelKey: 'customers' },
    { route: { name: 'shipping' }, icon: Truck, labelKey: 'shipping' },
    { route: { name: 'invoices' }, icon: FileText, labelKey: 'invoices' },
    { route: { name: 'reports' }, icon: BarChart3, labelKey: 'reports' },
    { route: { name: 'integrations' }, icon: Plug, labelKey: 'integrations' },
  ];

  const bottomNav: NavItem[] = [
    { route: { name: 'settings' }, icon: Settings, labelKey: 'settings' },
    // Help is a placeholder — navigate to settings for now
  ];

  const isActive = (name: Route['name']) => {
    if (current === 'order-detail' && name === 'orders') return true;
    if (current === 'create-order' && name === 'orders') return true;
    if (current === 'product-detail' && name === 'products') return true;
    if (current === 'customer-detail' && name === 'customers') return true;
    return current === name;
  };

  const handleNav = (item: NavItem) => {
    navigate(item.route);
    onCloseMobile();
  };

  return (
    <>
      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/50 lg:hidden animate-fade-in"
          onClick={onCloseMobile}
        />
      )}

      <aside className={classNames(
        'fixed inset-y-0 left-0 z-50 flex w-64 flex-col bg-slate-900 text-slate-300 transition-transform lg:translate-x-0 lg:static lg:z-auto',
        mobileOpen ? 'translate-x-0' : '-translate-x-full',
      )}>
        {/* Logo */}
        <div className="flex h-16 items-center justify-between px-5 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-blue-600">
              <LayoutDashboard className="h-5 w-5 text-white" />
            </div>
            <div>
              <span className="text-base font-bold text-white tracking-tight">ShopOS</span>
              <span className="ml-1 text-xs font-medium text-blue-400">v0.1</span>
            </div>
          </div>
          <button
            onClick={onCloseMobile}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white lg:hidden"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto px-3 py-4">
          <ul className="space-y-0.5">
            {mainNav.map((item) => {
              const active = isActive(item.route.name);
              const Icon = item.icon;
              return (
                <li key={item.route.name}>
                  <button
                    onClick={() => handleNav(item)}
                    className={classNames(
                      'group flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors',
                      active
                        ? 'bg-blue-600 text-white'
                        : 'text-slate-400 hover:bg-slate-800 hover:text-white',
                    )}
                  >
                    <Icon className={classNames('h-[18px] w-[18px] shrink-0', active ? 'text-white' : 'text-slate-500 group-hover:text-slate-300')} />
                    {t[item.labelKey] as string}
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* Bottom */}
        <div className="border-t border-slate-800 px-3 py-3 space-y-0.5">
          {bottomNav.map((item) => {
            const active = isActive(item.route.name);
            const Icon = item.icon;
            return (
              <button
                key={item.route.name}
                onClick={() => handleNav(item)}
                className={classNames(
                  'group flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors',
                  active ? 'bg-slate-800 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white',
                )}
              >
                <Icon className="h-[18px] w-[18px] text-slate-500 group-hover:text-slate-300" />
                {t[item.labelKey] as string}
              </button>
            );
          })}
          <button
            className="group flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
          >
            <LifeBuoy className="h-[18px] w-[18px] text-slate-500 group-hover:text-slate-300" />
            {t.help}
          </button>
        </div>
      </aside>
    </>
  );
}
